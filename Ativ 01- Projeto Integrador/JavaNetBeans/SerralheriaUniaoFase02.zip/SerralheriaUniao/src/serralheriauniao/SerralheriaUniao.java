package serralheriauniao;

import java.util.Locale;
import java.util.Scanner;
import usuario.Usuario;
import usuario.Funcionario;
import Cliente.cliente;
import Esquadria.Esquadria;
import Esquadria.distribuidorAluminio; 
import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import usuario.Cargo;
import Venda.Venda;
import Venda.formaPagamento;
import Venda.itemVenda;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SerralheriaUniao {

    private static boolean autenticarUsuario() {
        
        String usuarioFixo = "usuario";
        String senhaFixa = "senha";

        String usuario = JOptionPane.showInputDialog(null, "Usuário:");
        String senha = JOptionPane.showInputDialog(null, "Senha:");

        return usuario.equals(usuarioFixo) && senha.equals(senhaFixa);
    }

    private static void exibirMenu() {
        // Código do menu aqui
        
        System.out.println("S E R R A L H E R I A   U N I A O");
        System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
        
        System.out.println("ESQUADRIAS DE ALUMINIO  :");
        System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
        System.out.println("1) Setor Administrativo");
        System.out.println("2) Cadastro de Clientes");
        System.out.println("3) Cadastro de Produtos");
        System.out.println("4) Setor Financeiro");
        System.out.println("5) x");
        System.out.println("6) Sair");
        System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
        
    }
    public static void exibirMenuAdministrativo() {
        System.out.println("\nADMINISTRATIVO");
        System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
        System.out.println("1) Funcionarios.");
        System.out.println("2) Cargos");
        System.out.println("3) Usuarios");
        System.out.println("4) Sair\n");
        
        System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
        
       
    }
    public static void exibirMenuProduto() {
        System.out.println("\nProduto");
        System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
        System.out.println("1) Esquadrias");
        System.out.println("2) Fornecedor");
        System.out.println("3) xxx");
        System.out.println("4) Sair\n");
        
        System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
        
       
    }
    
    public static void exibirMenuFinanceiro() {
        System.out.println("\nFinanceiro");
        System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
        System.out.println("1) Venda");
        System.out.println("2) Item Venda");
        System.out.println("3) Forma de Pagamento");
        System.out.println("4) Sair\n");
        
        System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
        
       
    }


    public static void main(String[] args) {
        
        boolean autenticado = false;
        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);

        while (!autenticado) {
            autenticado = autenticarUsuario();

            if (!autenticado) {
                JOptionPane.showMessageDialog(null, "Usuário ou senha incorretos. Tente novamente.");
            }
        }

        int opcao;

        do {
            exibirMenu();

            System.out.print("ESCOLHA UMA OPCAO: ");
            opcao = sc.nextInt();
            System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
        
            
           
                switch (opcao) {
 case 1 -> {
                    

                    String senhaDigitada = JOptionPane.showInputDialog(null,"Digite a senha de acesso ao Administrativo: ");
                    
                    // Aqui você pode definir a senha correta para a opção administrativa
                    String senhaAdministrativo = "1234";

                    if (senhaDigitada.equals(senhaAdministrativo)) {
                        
                        int escolhaCliente;
                        do {
                            exibirMenuAdministrativo();
                            
                            System.out.print("ESCOLHA UMA OPCAO: ");
                            escolhaCliente = sc.nextInt();
                            
                            System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
        
                            
                            switch (escolhaCliente) {
                             
                                case 1 ->{
                                    
                                    List<Funcionario> listaFuncionarios = new ArrayList<>();
                                    
                                    listaFuncionarios.add(new Funcionario(1, "Edson Gularte da Silva", "13 99876 1234", "13 99876 6754", "2001-01-01", "0000-00-00", "000.000.000-00", "00000000000", "Avenida Copacabana", "798", "Bal. Monte Carlo", "Ilha Comprida", "2", "1"));
                                    listaFuncionarios.add(new Funcionario(2, "Carlos Alexandre da Silva", "13 99876 6578", "13 99876 9098", "2001-01-01 08:00:00", "0000-00-00 08:00:00", "000.000.000-00", "00000000000", "Alamenda São Judas Tadeu", "805", "Bal. Britania", "Ilha Comprida", "2", "3"));
                                    listaFuncionarios.add(new Funcionario(3, "Miguel Gularte", "13 99876 6677", "13 99876 9098", "2010-01-01 08:00:00", "0000-00-00 08:00:00", "000.000.000-00", "00000000000", "Alamenda São Judas Tadeu", "805", "Bal. Britania", "Ilha Comprida", "3"," 4"));
                                    listaFuncionarios.add(new Funcionario(4, "Bernardo Gularte", "13 99876 6677", "13 99876 8755", "2016-01-01 08:00:00", "0000-00-00 08:00:00", "000.000.000-00", "00000000000", "Alamenda São Paulo", "200", "Bal. Adriana", "Ilha Comprida","4", "5"));
                                    listaFuncionarios.add(new Funcionario(5, "Ana Paula", "13 99876 4321", "13 97654-9876", "2001-01-01 08:00:00", "0000-00-00 08:00:00", "000.000.000-00", "00000000000", "Alamenda São Judas Tadeu", "805", "Bal. Britania", "Ilha Comprida", "5", "6"));
                                    
                                    
                                    int escolha;
                                    
                                    do {
                                        System.out.println("\nCADASTRO E PESQUISA DE FUNCIONÁRIOS");
                                        System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                                        System.out.println("1) Cadastrar Funcionário.");
                                        System.out.println("2) Pesquisar Funcionário por Nome.");
                                        System.out.println("3) Excluir Funcionário.");
                                        System.out.println("4) Sair\n");
                                        System.out.print("ESCOLHA UMA OPÇÃO: ");
                                        escolha = sc.nextInt();
                                        System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                                        
                                        switch (escolha) {
                                            case 1 -> {
                                                String nomeFuncionario  = JOptionPane.showInputDialog(null, "Digite o nome do Funcionário: ");
                                                String telefone01Funcionario = JOptionPane.showInputDialog(null, "Digite o telefone 01 : ");
                                                String telefone02Funcionario = JOptionPane.showInputDialog(null, "Digite o telefone 02 : ");
                                                String dataAdmissaoFuncionario = JOptionPane.showInputDialog(null, "Digite a data de admissão do Funcionário: ");
                                                String dataDemissaoFuncionario = JOptionPane.showInputDialog(null, "Digite a data de demissao do Funcionário: ");
                                                String numCarteiraTrabalhoFuncionario = JOptionPane.showInputDialog(null, "Digite o número da Carteira de Trabalho: ");
                                                String registroGeralFuncionario  = JOptionPane.showInputDialog (null,"Digite o número do Registro Geral (RG) do Funcionário: ");
                                                String ruaFuncionario  = JOptionPane.showInputDialog (null,"Digite o Nome da Rua : ");
                                                String numeroFuncionario  = JOptionPane.showInputDialog (null,"Digite o número da casa : ");
                                                String balnearioFuncionario  = JOptionPane.showInputDialog (null,"Digite o Nome do Balneario: ");
                                                String cidadeFuncionario  = JOptionPane.showInputDialog (null,"Digite o Nome da Cidade: ");
                                                String usuarioIdFuncionario  = JOptionPane.showInputDialog (null,"Digite o ID do usuário : ");
                                                String cargoIdFuncionario = JOptionPane.showInputDialog (null,"Digite o ID do Cargo: ");
                                                Funcionario novoFuncionario = new Funcionario(listaFuncionarios.size() + 1, nomeFuncionario, telefone01Funcionario, telefone02Funcionario, dataAdmissaoFuncionario, dataDemissaoFuncionario, numCarteiraTrabalhoFuncionario, registroGeralFuncionario, ruaFuncionario, numeroFuncionario, balnearioFuncionario, cidadeFuncionario, usuarioIdFuncionario, cargoIdFuncionario);
                                                listaFuncionarios.add(novoFuncionario);
                                                JOptionPane.showMessageDialog (null,"\nCadastro de funcionário realizado com sucesso.\n");
                                                System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                            }
                                            case 2 -> {
                                                sc.nextLine();
                                                String nomeBusca = JOptionPane.showInputDialog (null,"Digite o nome do Funcionário que deseja pesquisar:  ");
                                                boolean funcionarioEncontrado = false;
                                                for (Funcionario funcionario : listaFuncionarios) {
                                                    if (funcionario.getNome().equalsIgnoreCase(nomeBusca)) {
                                                        System.out.println("\nFuncionário encontrado: " + funcionario.getNome());
                                                        System.out.println("Telefone 01: " + funcionario.getTelefone01());
                                                        System.out.println("Telefone 02: " + funcionario.getTelefone02());
                                                        System.out.println("Data de Admissão: " + funcionario.getDataadmissao());
                                                        System.out.println("Data de Demissão: " + funcionario.getDataDemissao());
                                                        System.out.println("Número da Carteira de Trabalho: " + funcionario.getNumcarteiraTrabalho());
                                                        System.out.println("Registro Geral (RG): " + funcionario.getRegistrogeral());
                                                        System.out.println("Rua: " + funcionario.getRua());
                                                        System.out.println("Número: " + funcionario.getNumero());
                                                        System.out.println("Balneário: " + funcionario.getBalneario());
                                                        System.out.println("Cidade: " + funcionario.getCidade());
                                                        System.out.println("ID do Usuário: " + funcionario.getUsuarioId());
                                                        System.out.println("ID do Cargo: " + funcionario.getCargoId());
                                                        System.out.println("\n");
                                                        funcionarioEncontrado = true;
                                                    }
                                                }   if (!funcionarioEncontrado) {
                                                    System.out.println("\nFuncionário não encontrado.");
                                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                }
                                            }
                                            case 3 -> {
                                                sc.nextLine(); // Limpa o buffer
                                                System.out.print("Digite o nome do Funcionário que deseja excluir: ");
                                                String nomeExcluir = sc.nextLine();
                                                boolean funcionarioExcluido = false;
                                                for (int i = 0; i < listaFuncionarios.size(); i++) {
                                                    if (listaFuncionarios.get(i).getNome().equalsIgnoreCase(nomeExcluir)) {
                                                        listaFuncionarios.remove(i);
                                                        funcionarioExcluido =
                                                                
                                                                true;
                                                        break;
                                                    }
                                                }   if (funcionarioExcluido) {
                                                    System.out.println("\nFuncionário excluído com sucesso.");
                                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                } else {
                                                    System.out.println("\nFuncionário não encontrado para excluir.");
                                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                }
                                            }
                                            case 4 -> JOptionPane.showMessageDialog(
                                                        
                                                        null, " ----- CADASTRO FINALIZADO -----");
                                            default -> System.out.println("Opção inválida. Digite novamente.\n");
                                        }
                                        
                                    } while (escolha != 4);
                                    
                                } case 2 -> {
                                    
                                    List<Cargo> listaCargo = new ArrayList<>();
                                    
                                    listaCargo.add(new Cargo(1, "Proprietario", "Responsavel pela Loja", 8000.00));
                                    listaCargo.add(new Cargo(2, "Gerente", "Gerencia os Funcionários, cuida da parte Administrativa", 7000.00));
                                    listaCargo.add(new Cargo(3, "Serralheiro Alumínio", "Profissional que fabrica e executa as instalações", 5000.00));
                                    listaCargo.add(new Cargo(4, "Meio Oficial", "Profissional que auxilia o Serralheiro", 3000.00));
                                    listaCargo.add(new Cargo(5, "Vendedor", "Supervisor de Vendas", 3000.00));
                                    
                                    int escolhaCargo;
                                    
                                    do {
                                        System.out.println("\nCargos");
                                        System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                                        System.out.println("1) Pesquisar Cargos.");
                                        System.out.println("2) Sair\n");
                                        System.out.print("ESCOLHA UMA OPCAO: ");
                                        escolhaCargo = sc.nextInt();
                                        System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                        
                                        switch (escolhaCargo) {
                                            case 1 -> {
                                                if (listaCargo.isEmpty()) {
                                                    System.out.println("\nNenhum cargo cadastrado.");
                                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                    break;
                                                }
                                                
                                                String nomeBusca = JOptionPane.showInputDialog(null,"Digite o nome do cargo que deseja pesquisar: ");
                                                System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                
                                                boolean cargoEncontrado = false;
                                                
                                                for (Cargo cargo : listaCargo) {
                                                    if (cargo.getNome().equalsIgnoreCase(nomeBusca)) {
                                                        System.out.println("\nCargo encontrado: " + cargo.getNome());
                                                        System.out.println("Código: " + cargo.getCodigo());
                                                        System.out.println("Descrição: " + cargo.getDescricao());
                                                        System.out.println("Salário: " + cargo.getSalario());
                                                        System.out.println("\n");
                                                        
                                                        cargoEncontrado = true;
                                                    }
                                                }
                                                
                                                if (!cargoEncontrado) {
                                                    System.out.println("\nCargo não encontrado.");
                                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                }
                                            }
                                                
                                            case 2 -> System.out.println("Saindo...");
                                                
                                            default -> System.out.println("Opção inválida. Digite novamente.\n");
                                        }
                                        
                                    } while (escolhaCargo != 2);
                                    
                                    break;
                                } case 3 -> {
                                    
                                    Usuario[] usuarios = new Usuario[6];
                                    
                                    usuarios[0] = new Usuario(0, "admin", "123456A", "2023-01-02 08:00:00");
                                    usuarios[1] = new Usuario(1, "proprietario", "123456B", "2023-01-02 08:00:00");
                                    usuarios[2] = new Usuario(2, "gerente", "123456C", "2023-01-02 08:00:00");
                                    usuarios[3] = new Usuario(3, "serralheiro", "123456D", "2023-01-02 08:00:00");
                                    usuarios[4] = new Usuario(4, "meioOficial", "123456E", "2023-01-02 08:00:00");
                                    usuarios[5] = new Usuario(5, "vendedor", "123456F", "2023-01-02 08:00:00");
                                    
                                    int escolhaUsuario;
                                    
                                    do {
                                        System.out.println("\nUsuários");
                                        System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                                        System.out.println("1) Pesquisar Usuários.");
                                        System.out.println("2) Sair\n");
                                        System.out.print("ESCOLHA UMA OPÇÃO: ");
                                        escolhaUsuario = sc.nextInt();
                                        System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                        
                                        switch (escolhaUsuario) {
                                            case 1 ->                   {
                                                String nomeBusca = JOptionPane.showInputDialog(null,"Digite o nome do Usuario que deseja pesquisar: ");
                                                System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                
                                                boolean usuarioEncontrado = false;
                                                
                                                for (Usuario usuario : usuarios) {
                                                    if (usuario.getNome().equalsIgnoreCase(nomeBusca)) {
                                                        System.out.println("\nUsuário encontrado: " + usuario.getNome());
                                                        System.out.println("ID do Usuário: " + usuario.getIdUsuario());
                                                        System.out.println("Senha: " + usuario.getSenha());
                                                        System.out.println("Data de Cadastro: " + usuario.getDataCadastro());
                                                        System.out.println("\n");
                                                        
                                                        usuarioEncontrado = true;
                                                        break;
                                                    }
                                                }
                                                
                                                if (!usuarioEncontrado) {
                                                    System.out.println("\nUsuário não encontrado.");
                                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                }                       }
                                            
                                            case 2 -> System.out.println("Saindo...");
                                            
                                            default -> System.out.println("Opção inválida. Digite novamente.\n");
                                        }
                                        
                                    } while (escolhaUsuario != 2);
                                    
                                }
                                
                                case 4 -> {
                                }
                                
                            }
                            
                        }while (escolhaCliente != 4);
                        
                    }
                }
case 2 -> {
                    
                    List<cliente> listaClientes = new ArrayList<>();

                            listaClientes.add(new cliente("1", "Adriano de Souza", "11 96214 6625", null, "29043921068", "Rua Franca","470", "Bal. Icarai", "Ilha Comprida"));
                            listaClientes.add(new cliente("2", "Gabriel Medina", "13 99876 6578", null, "22724372069", "Rua Franca","470", "Bal. Icarai", "Ilha Comprida"));
                            listaClientes.add(new cliente("3", "Felipe Toledo", "13 99876 6578", null, "59610341004", "Rua Casa Verde","60", "Bal. Leão de Iguape", "Ilha Comprida"));
                            listaClientes.add(new cliente("4", "Italo Ferreira", "13 99777 0301", null, "89476252057", "Rua da Garças","38", "Bal. Mar e Sol", "Ilha Comprida"));
                            listaClientes.add(new cliente("5", "Raissa Leal", "15 99757 6618", null, "41507587007", "Rua das Papoulas","987", "Bal. Porto Velho", "Ilha Comprida"));
                            listaClientes.add(new cliente("6", "Peterson Rosa", "13 99764 7676", null, "95837653090", "Rua Cascata","160", "Bal. Atlantico", "Ilha Comprida"));
                            listaClientes.add(new cliente("7", "Pamela Rosa", "11 99876 9956", null, "76798976034", "Rua Rio Grande do Norte","540", "Bal. Adriana", "Ilha Comprida"));
                            listaClientes.add(new cliente("8", "Gustavo Borges", "67 99876 4433", null, "49008644045", "Rua Cuiaba","150", "Bal. Adriana", "Ilha Comprida"));
                            listaClientes.add(new cliente("9", "Leticia Sabatela", "15 99764 8201", null, "29346675020", "Rua Cuiaba","150", "Bal. Adriana", "Ilha Comprida"));
                            listaClientes.add(new cliente("10", "Fabio Gouveia", "11 94910 5239", null, "44450569016", "Rua Tino Gonsalves Dias","549", "Bal. Britania", "Ilha Comprida"));

                        int escolha;
                        int qtdClientes = listaClientes.size();

                        do {
                            System.out.println("\nCADASTRO DE CLIENTES");
                            System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                            System.out.println("1) Fazer um Cadastro.");
                            System.out.println("2) Pesquisar");
                            System.out.println("3) Excluir Cliente");
                            System.out.println("4) Sair\n");
                            System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                            System.out.print("ESCOLHA UMA OPCAO: ");
                            escolha = sc.nextInt();
                            System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");

                            switch (escolha) {
                                case 1 -> {
                                    if (qtdClientes >= 30) {
                                        System.out.println("Limite máximo de clientes atingido.");
                                        break;
                                    }

                                    String idCliente = Integer.toString(qtdClientes + 1);
                                    String nome = JOptionPane.showInputDialog(null, "Nome do cliente:");
                                    String telefone01 = JOptionPane.showInputDialog(null, "Digite o Numero do Telefone 01: ");
                                    String telefone02 = JOptionPane.showInputDialog(null, "Digite o Numero do Telefone 02: ");
                                    String cpf = JOptionPane.showInputDialog(null, "Digite o Numero do Cpf: ");
                                    String rua = JOptionPane.showInputDialog(null, "Digite o Nome da Rua: ");
                                    String numero = JOptionPane.showInputDialog(null, "Digite o Numero: ");
                                    String balneario = JOptionPane.showInputDialog(null, "Digite o Nome do Balneario: ");
                                    String cidade = JOptionPane.showInputDialog(null, "Digite o Nome da Cidade: ");

                                    cliente novoCliente = new cliente(idCliente, nome, telefone01, telefone02, cpf, rua, numero, balneario, cidade);
                                    listaClientes.add(novoCliente);
                                    qtdClientes++;

                                    JOptionPane.showMessageDialog(null, "\nCadastro realizado com sucesso.\n");
                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                    break;
                                }

                                case 2 -> {
                                    if (listaClientes.isEmpty()) {
                                        System.out.println("\nNenhum cliente cadastrado.");
                                        System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                        break;
                                    }

                                    sc.nextLine(); // Limpar o buffer do teclado
                                    String nomeBusca = JOptionPane.showInputDialog("\nDigite o nome do Cliente que deseja pesquisar: ");

                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");

                                    int cadastro = -1;
                                    for (int i = 0; i < listaClientes.size(); i++) {
                                        if (listaClientes.get(i).getNome().equalsIgnoreCase(nomeBusca)) {
                                            cadastro = i;
                                            break;
                                        }
                                    }

                                    if (cadastro >= 0) {
                                        cliente clienteEncontrado = listaClientes.get(cadastro);
                                        System.out.println("\nCliente " + nomeBusca + " foi encontrado no Cadastro " + cadastro);
                                        System.out.println("IdCliente: " + clienteEncontrado.getIdCliente());
                                        System.out.println("Nome: " + clienteEncontrado.getNome());
                                        System.out.println("Telefone 01: " + clienteEncontrado.getTelefone01());
                                        System.out.println("Telefone 02: " + clienteEncontrado.getTelefone02());
                                        System.out.println("Numero Cpf: " + clienteEncontrado.getCpf());
                                        System.out.println("Rua: " + clienteEncontrado.getRua());
                                        System.out.println("Numero: " + clienteEncontrado.getNumero());
                                        System.out.println("Balneario: " + clienteEncontrado.getBalneario());
                                        System.out.println("Cidade: " + clienteEncontrado.getCidade());
                                        System.out.println("\n");

                                        System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                    } else {
                                        System.out.println("\nCliente não encontrado.");
                                        System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                    }
                                    break;
                                }

                case 3 -> {
                                    if (listaClientes.isEmpty()) {
                                        System.out.println("\nNenhum cliente cadastrado para excluir.");
                                        System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                        break;
                                    }

                                    String nomeExcluir = JOptionPane.showInputDialog("\nDigite o nome do Cliente que deseja excluir: ");

                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");

                                    boolean clienteExcluido = false;
                                    for (int i = 0; i < listaClientes.size(); i++) {
                                        if (listaClientes.get(i).getNome().equalsIgnoreCase(nomeExcluir)) {
                                            listaClientes.remove(i);
                                            clienteExcluido = true;
                                            qtdClientes--;
                                            break;
                                        }
                                    }

                                    if (clienteExcluido) {
                                        System.out.println("\nCliente " + nomeExcluir + " foi excluído com sucesso.");
                                        System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                    } else {
                                        System.out.println("\nCliente não encontrado para excluir.");
                                        System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                    }

                                    break;
                                }
                                case 4 -> JOptionPane.showMessageDialog(null, " ----- CADASTRO FINALIZADO -----");
                                default -> System.out.print("Opção inválida. Digite novamente.\n");
                            }

        } while (escolha != 4);
                        
} case 3 -> {
    
                    String senhaDigitada = JOptionPane.showInputDialog(null,"Digite a senha de acesso ao Menu Produto: ");
                    
                    
                    String senhaProduto = "1234";

                    if (senhaDigitada.equals(senhaProduto)) {
                        
                        int escolhaProduto;
                        do {
                            exibirMenuProduto();
                            
                            System.out.print("ESCOLHA UMA OPCAO: ");
                            escolhaProduto = sc.nextInt();
                            System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
        
                            
                            switch (escolhaProduto) {
                             
                                case 1 ->{
                                     List<Esquadria> listaEsquadrias = new ArrayList<>();
                        
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "1","Tela de Proteção","Tela de Proteção contra Insetos","160.00","1")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "2","Box de Vidro","Box de Vidro Temperado para Banho","380.00","3")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "3","Abrigo de Pia em Aluminio","Abrigo para Pia de Cozinha","500.00","1")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "4","Abrigo de Pia em Acrilico","Abrigo para Pia de Cozinha","300.00","2")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "5","Grades de Proteção","Grades de Proteção com Ferro","450.00","1")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "6","Porta de Tela","Porta de Tela de Proteção contra Insetos","550.00","2")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "7","Porta de Giro Fechada","Porta de Giro fechada em Paletas","640.00","1")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "8","Portão Fechado Aluminio Branco","Portão de Alumínio Deslizante","750.00","1")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "9","Portão Fechado Aluminio Bronze","Portão de Alumínio Deslizante","800.00","2")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "10","Portão Fechado Lambril Simples","Portão de Alumínio Deslizante","750.00","4")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "11","Portão Fechado Lambril Duplo","Portão de Alumínio Deslizante","830.00","4")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "12","Portão de Regua","Portão de Alumínio Deslizante","750.00","1")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "13","Portão de Tubo Simples","Portão de Alumínio Deslizante","690.00","1")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "14","Janela Linha Suprema 2 folhas","Janela de Alumínio Branco com 2 folhas e vidro","600.00","3")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "15","Janela Linha Suprema 4 folhas","Janela de Alumínio Branco com 4 folhas e vidro","800.00","4")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "16","Janela Linha Vidro Temperado 4 folhas","Janela de Vidro Temperado com 4 folhas","900.00","3")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "17","Portão Social Fechado","Portão Social 2.10 x 0.90","950.00","1")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "18","Veneziana Linha Suprema 3 folhas","Janela para Quarto 3 folhas Deslizantes","800.00","1")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "19","Veneziana Linha Suprema 6 folhas","Janela para Quarto 6 folhas Deslizantes","950.00","1")); 
                        listaEsquadrias.add(new Esquadria(listaEsquadrias.size() + 1, "20","Vitro Basculhante","Vitro Basculante para Banheiro","450.00","1")); 
                        
                            int escolhaEsquadria;
                                    
                            do {
                                
                            System.out.println("\nCADASTRO DE PRODUTOS");
                            System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                            System.out.println("1) Fazer um Cadastro.");
                            System.out.println("2) Pesquisar");
                            System.out.println("3) Excluir");
                            System.out.println("4) Sair\n");
                            System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                            System.out.print("ESCOLHA UMA OPCAO: ");
                            escolhaEsquadria = sc.nextInt();
                            System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");

                        
                                         switch (escolhaEsquadria) {
                                             case 1 -> {
                                                 String idEsquadria =  JOptionPane.showInputDialog(null, "IdEsquadria:");
                                                 String nomeEsquadria = JOptionPane.showInputDialog(null, "Nome da Esquadria:");
                                                 String descricao = JOptionPane.showInputDialog(null, "Descrição: ");
                                                 String preco = JOptionPane.showInputDialog(null, "Preço: ");
                                                 String distribuidorAluminioId = JOptionPane.showInputDialog(null, "Distribuidor Aluminio ID: ");
                                                 Esquadria novaEsquadria = new Esquadria(listaEsquadrias.size() + 1, idEsquadria, nomeEsquadria, descricao, preco, distribuidorAluminioId);
                                                 listaEsquadrias.add(novaEsquadria);
                                                 JOptionPane.showMessageDialog (null,"\nCadastro de Esquadria Realizado com Sucesso.\n");
                                                 System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                             }
                                             case 2 -> {
                                                 sc.nextLine();
                                                 String nomeBusca = JOptionPane.showInputDialog (null,"Digite o nome da Esquadria que deseja pesquisar:  ");
                                                 boolean esquadriaEncontrada = false;
                                                 for (Esquadria esquadria : listaEsquadrias) {
                                                     if (esquadria.getNomeEsquadria().equalsIgnoreCase(nomeBusca)) {
                                                         System.out.println("\nEsquadria encontrada: " + esquadria.getNomeEsquadria());
                                                         System.out.println("Descricao: " + esquadria.getDescricao());
                                                         System.out.println("Preco: " + esquadria.getPreco());
                                                         System.out.println("DistribuidorAluminioId: " + esquadria.getDistribuidorAluminioId());
                                                         System.out.println("\n");
                                                         esquadriaEncontrada = true;
                                                     }
                                                 }    if (!esquadriaEncontrada) {
                                                     System.out.println("\nEsquadria não encontrada.");
                                                     System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                 }
                                             }
                                             case 3 -> {
                                                 sc.nextLine(); // Limpa o buffer
                                                 System.out.print("Digite o nome da Esquadria que deseja excluir: ");
                                                 String nomeExcluir = sc.nextLine();
                                                 boolean esquadriaExcluida = false;
                                                 for (int i = 0; i < listaEsquadrias.size(); i++) {
                                                     if (listaEsquadrias.get(i).getNomeEsquadria().equalsIgnoreCase(nomeExcluir)) {
                                                         listaEsquadrias.remove(i);
                                                         esquadriaExcluida = true;
                                                         break;
                                                     }
                                                 }    if (esquadriaExcluida) {
                                                     System.out.println("\nEsquadria excluída com sucesso.");
                                                     System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                 } else {
                                                     System.out.println("\nEsquadria não encontrada para excluir.");
                                                     System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                 }
                                             }
                                             case 4 -> JOptionPane.showMessageDialog(
                                                         
                                                         null, " ----- CADASTRO FINALIZADO -----");
                                             default -> System.out.println("Opção inválida. Digite novamente.\n");
                                         }
                                        
                                    } while (escolhaEsquadria != 4);
                                    
                                
                                } case 2 -> {
                                    
                                    List<distribuidorAluminio> listaDistribuidorAluminio = new ArrayList<>();
                        
                        
                                    listaDistribuidorAluminio.add(new distribuidorAluminio(listaDistribuidorAluminio.size() + 1, "1","Ideal Aluminio","000.000.000-00","13 99876 1234", "13 99876 5678", "Compras Aluminio", "Neia","Praia Grande","SP"));
                                    listaDistribuidorAluminio.add(new distribuidorAluminio(listaDistribuidorAluminio.size() + 1, "2","AlumiSantos","000.000.000-00","13 99876 5678", "13 99876 1233","Administrativo", "Paulo Roberto", "Praia Grande", "SP"));
                                    listaDistribuidorAluminio.add(new distribuidorAluminio(listaDistribuidorAluminio.size() + 1, "3","Ferragens Rodrigues","000.000.000-00","15 99876 7834","15 99876 7654", "Compras Aluminio", "Roberta","Sorocaba","SP"));
                                    listaDistribuidorAluminio.add(new distribuidorAluminio(listaDistribuidorAluminio.size() + 1, "4","Litoral Aluminio","000.000.000-00","13 99833 9836", "13 99803 5467", "Compras Aluminio", "Carlos","Santos","SP"));

                        int escolhaDistribuidor;
                                    
                            do {
                                
                            System.out.println("\nDISTRIBUIDORES");
                            System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                            System.out.println("1) Fazer um Cadastro.");
                            System.out.println("2) Pesquisar");
                            System.out.println("3) Excluir");
                            System.out.println("4) Sair\n");
                            System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                            System.out.print("ESCOLHA UMA OPCAO: ");
                            escolhaDistribuidor = sc.nextInt();
                            System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");

                        
                                        switch (escolhaDistribuidor) {
                                            case 1 -> {
                                                String idDistribuidorAluminio =  JOptionPane.showInputDialog(null, "IdDistribuidorAluminio:");
                                                String nomeEmpresa = JOptionPane.showInputDialog(null, "Nome da Empresa:");
                                                String cnpj = JOptionPane.showInputDialog(null, "Cnpj: ");
                                                String telefone01 = JOptionPane.showInputDialog(null, "Telefone 01: ");
                                                String telefone02 = JOptionPane.showInputDialog(null, "Telefone 01: ");
                                                String setor = JOptionPane.showInputDialog(null, "Setor: ");
                                                String responsavel = JOptionPane.showInputDialog(null, "Responsavel: ");
                                                String cidade = JOptionPane.showInputDialog(null, "Cidade: ");
                                                String Estado = JOptionPane.showInputDialog(null, "Estado: ");
                                                distribuidorAluminio novoDistribuidor = new distribuidorAluminio( listaDistribuidorAluminio.size() + 1, idDistribuidorAluminio, nomeEmpresa, cnpj, telefone01, telefone02, setor, responsavel, cidade, Estado);
                                                listaDistribuidorAluminio.add(novoDistribuidor);
                                                JOptionPane.showMessageDialog (null,"\nCadastro de Distribuidor Realizado com Sucesso.\n");
                                                System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                            }
                                            case 2 -> {
                                                sc.nextLine();
                                                String nomeBusca = JOptionPane.showInputDialog (null,"Digite o nome da Esquadria que deseja pesquisar:  ");
                                                boolean distribuidorEncontrado = false;
                                                for ( distribuidorAluminio distribuidorAluminio : listaDistribuidorAluminio) {
                                                    if (distribuidorAluminio.getNomeEmpresa().equalsIgnoreCase(nomeBusca)) {
                                                        System.out.println("\nDistrbuidor encontrada: " + distribuidorAluminio.getNomeEmpresa());
                                                        System.out.println("CNPJ: " + distribuidorAluminio.getCnpj());
                                                        System.out.println("Telefone 01: " + distribuidorAluminio.getTelefone01());
                                                        System.out.println("Telefone 02" + distribuidorAluminio.getTelefone02());
                                                        System.out.println("Setor: " + distribuidorAluminio.getSetor());
                                                        System.out.println("Responsavel: " + distribuidorAluminio.getResponsavel());
                                                        System.out.println("Cidade" + distribuidorAluminio.getCidade());
                                                        System.out.println("Estado" + distribuidorAluminio.getEstado());
                                                        
                                                        System.out.println("\n");
                                                        distribuidorEncontrado = true;
                                                    }
                                                }   if (!distribuidorEncontrado) {
                                                    System.out.println("\nDistribuidor não encontrada.");
                                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                }
                                            }
                                            case 3 -> {
                                                sc.nextLine(); // Limpa o buffer
                                                System.out.print("Digite o nome da Esquadria que deseja excluir: ");
                                                String nomeExcluir = sc.nextLine();
                                                boolean esquadriaExcluida = false;
                                                for (int i = 0; i < listaDistribuidorAluminio.size(); i++) {
                                                    if (listaDistribuidorAluminio.get(i).getNomeEmpresa().equalsIgnoreCase(nomeExcluir)) {
                                                        listaDistribuidorAluminio.remove(i);
                                                        esquadriaExcluida =
                                                                
                                                                true;
                                                        break;
                                                    }
                                                }   if (esquadriaExcluida) {
                                                    System.out.println("\nDistribuidor excluído com sucesso.");
                                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                } else {
                                                    System.out.println("\nDistribuidor não encontrado para excluir.");
                                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                }
                                            }
                                            case 4 -> JOptionPane.showMessageDialog(
                                                        
                                                        null, " ----- CADASTRO FINALIZADO -----");
                                            default -> System.out.println("Opção inválida. Digite novamente.\n");
                                        }
                                        
                                    } while (escolhaDistribuidor != 4);
                                    
                                } case 3 -> { 
                                    
                                    
                               }
                                
                                case 4 -> {  
                JOptionPane.showMessageDialog(null, " ----- CADASTRO FINALIZADO -----");
                                  
                                 } 
                            }
                        }while (escolhaProduto != 4);
                    }
                }
                case 4 ->  {
    
                    String senhaDigitada = JOptionPane.showInputDialog(null,"Digite a senha de acesso ao Menu Financeiro: ");
                    
                    
                    String senhaFinanceiro = "1234";

                    if (senhaDigitada.equals(senhaFinanceiro)) {
                        
                        int escolhaFinanceiro;
                        do {
                            exibirMenuFinanceiro();
                            
                            System.out.print("ESCOLHA UMA OPCAO: ");
                            escolhaFinanceiro = sc.nextInt();
                            System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
        
                            
                            switch (escolhaFinanceiro) {
                             
                               case 1 -> {
                        List<Venda> listaVendas = new ArrayList<>();
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

                        listaVendas.add(new Venda(listaVendas.size() + 1, new Date(), new Date(), 240.00, 1, 5));
                        listaVendas.add(new Venda(listaVendas.size() + 1, new Date(), new Date(), 1083.00, 2, 5));
                        listaVendas.add(new Venda(listaVendas.size() + 1, new Date(), new Date(), 4475.00, 4, 5));
                        listaVendas.add(new Venda(listaVendas.size() + 1, new Date(), new Date(), 9994.20, 3, 5));

                        int escolhaVenda;

                        do {
                            System.out.println("\nVENDAS");
                            System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                            System.out.println("1) Registrar Venda:");
                            System.out.println("2) ( Pesquisar/Imprimir ) Comprovante:");
                            System.out.println("3) Excluir Comprovante:");
                            System.out.println("4) Sair:\n");
                            System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                            System.out.print("ESCOLHA UMA OPCAO: ");
                            escolhaVenda = sc.nextInt();
                            System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");

                            switch (escolhaVenda) {

                                case 1 -> {
                                    System.out.print("\nidVenda: ");
                                    int idVenda = sc.nextInt();

                                    sc.nextLine(); // Limpa o buffer
                                    System.out.print("Data da Compra (yyyy-MM-dd): ");
                                    String dataVendaStr = sc.nextLine();

                                    if (dataVendaStr.isEmpty()) {
                                        // Tratar caso a data seja vazia
                                        System.out.println("Data da Compra não pode ser vazia.");
                                        // Encerrar a operação
                                    }

                                    Date dataVenda = null;
                                    try {
                                        dataVenda = sdf.parse(dataVendaStr);
                                    } catch (ParseException e) {
                                        System.out.println("Data da Compra inválida. Utilize o formato yyyy-MM-dd.");
                                        // Encerrar a operação
                                    }

                                    System.out.print("Data da Entrega (yyyy-MM-dd): ");
                                    String dataEntregaStr = sc.nextLine();

                                    if (dataEntregaStr.isEmpty()) {
                                        // Tratar caso a data seja vazia
                                        System.out.println("Data da Entrega não pode ser vazia.");
                                        // Encerrar a operação
                                    }

                                    Date dataEntrega = null;
                                    try {
                                        dataEntrega = sdf.parse(dataEntregaStr);
                                    } catch (ParseException e) {
                                        System.out.println("Data da Entrega inválida. Utilize o formato yyyy-MM-dd.");
                                        // Encerrar a operação
                                    }

                                    System.out.print("Valor Total: ");
                                    double valorTotal = sc.nextDouble();

                                    System.out.print("clienteId: ");
                                    int clienteId = sc.nextInt();

                                    System.out.print("funcionarioId: ");
                                    int funcionarioId = sc.nextInt();

                                    Venda novaVenda = new Venda(listaVendas.size() + 1, dataVenda, dataEntrega, valorTotal, clienteId, funcionarioId);
                                    listaVendas.add(novaVenda);

                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                    System.out.println("Venda Cadastrada com Sucesso.");
                                    System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                                }
 
                              case 2 -> {
                                  
                                  if (listaVendas.isEmpty()) {
                                      System.out.println("Não há vendas cadastradas.");
                                      break;
                                  }
                                  
                                  System.out.println("\nPESQUISAR COMPROVANTE DE VENDA");
                                  System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                                  
                                  System.out.print("Digite o ID da venda que deseja pesquisar: ");
                                  int idVendaPesquisa = sc.nextInt();
                                  
                                  boolean vendaEncontrada = false;
                                  
                                  
                                  for (Venda venda : listaVendas) {
                                      if (venda.getIdVenda() == idVendaPesquisa) {
                                          System.out.println("ID da Venda: " + venda.getIdVenda());
                                          System.out.println("Data da Compra: " + venda.getDataVenda());
                                          System.out.println("Data da Entrega: " + venda.getDataEntrega());
                                          System.out.println("Valor Total: " + venda.getValorTotal());
                                          System.out.println("ID do Cliente: " + venda.getClienteId());
                                          System.out.println("ID do Funcionário: " + venda.getFuncionarioId());
                                          System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                                          vendaEncontrada = true;
                                          break;
                                      }
                                  }
                                  
                                  if (!vendaEncontrada) {
                                      System.out.println("Venda não encontrada.");
                                      System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
                                  }
                              } case 3 -> {
                                  
                                  
                                                sc.nextLine(); // Limpa o buffer
                                                System.out.print("Digite o Id da Venda que deseja excluir: ");
                                                int idExcluir = sc.nextInt();
                                                boolean vendaExcluida = false;
                                                for (int i = 0; i < listaVendas.size(); i++) {
                                                    if (listaVendas.get(i).getIdVenda() == idExcluir) {
                                                        listaVendas.remove(i);
                                                        vendaExcluida =
                                                                
                                                                true;
                                                        break;
                                                    } else {
                                                    }
                                                }   if (vendaExcluida) {
                                                    System.out.println("\nVenda excluída com sucesso.");
                                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                } else {
                                                    System.out.println("\nVenda não encontrada para excluir.");
                                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                                
                                                }
                                                    break;          
                                                }
                                  
                                case 4 -> {
                                    
                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                    System.out.println("\nVenda Cadastrada com Sucesso.");
                                    System.out.println("_____________________________________________________________________________________________________________________________________________\n\n");
                                   break;             
                                    
                           }
                                                
                       }
                                    
                                }while(escolhaVenda != 4);
                            
                              } case 2 -> {
                                }
                                case 3 -> {
                                }
                                case 4 -> {
                                            } 
                            }
                        }while (escolhaFinanceiro != 4);
                    }
                }
                case 5 -> {
                }
                
                case 6 -> JOptionPane.showMessageDialog(null, "\n\n ----- PROGRAMA FINALIZADO -----\n\n");
                default -> JOptionPane.showMessageDialog(null, "\nDigite um número válido.");
            }
            
                    }while (opcao != 6);
    } 
}



    
            
            
    
    

