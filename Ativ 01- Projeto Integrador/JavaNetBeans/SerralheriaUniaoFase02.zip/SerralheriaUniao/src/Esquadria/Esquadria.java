package Esquadria;

    public class Esquadria {
    
        private String idEsquadria;
        private String nomeEsquadria;
        private String descricao;
        private String preco;
        private String distribuidorAluminioId;
        
        
    public Esquadria(int par, String idEsquadria, String nomeEsquadria, String descricao, String preco, String distribuidorAluminioId) {
        this.idEsquadria = idEsquadria;
        this.nomeEsquadria = nomeEsquadria;
        this.descricao = descricao;
        this.preco = preco;
        this.distribuidorAluminioId = distribuidorAluminioId;
        
        
    }

    

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    public Esquadria(String preco) {
        this.preco = preco;
    }

    public String getIdEsquadria() {
        return idEsquadria;
    }

    public void setIdEsquadria(String idEsquadria) {
        this.idEsquadria = idEsquadria;
    }

    public String getNomeEsquadria() {
        return nomeEsquadria;
    }

    public void setNomeEsquadria(String nomeEsquadria) {
        this.nomeEsquadria = nomeEsquadria;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getDistribuidorAluminioId() {
        return distribuidorAluminioId;
    }

    public void setDistribuidorAluminioId(String distribuidorAluminioId) {
        this.distribuidorAluminioId = distribuidorAluminioId;
    }
    
    public void exibirDetalhesEsquadria() {
        System.out.println("ID da Esquadria: " + idEsquadria);
        System.out.println("Nome da Esquadria: " + nomeEsquadria);
        System.out.println("Descrição: " + descricao);
        System.out.println("Preço: " + preco);
        System.out.println("Distribuidor de Alumínio ID: " + distribuidorAluminioId);
        System.out.println();
    }
        

}
