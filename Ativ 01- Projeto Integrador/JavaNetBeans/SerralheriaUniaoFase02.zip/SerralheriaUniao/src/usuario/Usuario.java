package usuario;


    public class Usuario {
    private int idUsuario;
    private String nome;
    private String senha;
    private String dataCadastro;

    public Usuario(int idUsuario, String nome, String senha, String dataCadastro) {
        this.idUsuario = idUsuario;
        this.nome = nome;
        this.senha = senha;
        this.dataCadastro = dataCadastro;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public String getNome() {
        return nome;
    }

    public String getSenha() {
        return senha;
    }

    public String getDataCadastro() {
        return dataCadastro;
    }
}

