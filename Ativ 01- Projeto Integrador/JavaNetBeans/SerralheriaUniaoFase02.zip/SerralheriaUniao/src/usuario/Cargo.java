package usuario;

    public class Cargo {
    private int codigo;
    private String nome;
    private String descricao;
    private double salario;

    public Cargo(int codigo, String nome, String descricao, double salario) {
        this.codigo = codigo;
        this.nome = nome;
        this.descricao = descricao;
        this.salario = salario;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public double getSalario() {
        return salario;
    }
}
