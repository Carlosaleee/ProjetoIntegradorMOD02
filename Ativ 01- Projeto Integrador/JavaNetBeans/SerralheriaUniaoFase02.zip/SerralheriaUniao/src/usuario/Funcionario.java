package usuario;


    public class Funcionario {
        
        private int idFuncionario;
        private String  nome;
        private String telefone01;
        private String telefone02;
        private String dataadmissao;
        private String dataDemissao;
        private String numcarteiraTrabalho;
        private String registrogeral;
        private String rua;
        private String numero;
        private String balneario;
        private String cidade;
        private String usuarioId;
        private String cargoId;

    public Funcionario(int idFuncionario, String nome, String telefone01, String telefone02, String dataadmissao, String dataDemissao, String numcarteiraTrabalho, String registrogeral, String rua, String numero, String balneario, String cidade, String usuarioId, String cargoId) {
        this.idFuncionario = idFuncionario;
        this.nome = nome;
        this.telefone01 = telefone01;
        this.telefone02 = telefone02;
        this.dataadmissao = dataadmissao;
        this.dataDemissao = dataDemissao;
        this.numcarteiraTrabalho = numcarteiraTrabalho;
        this.registrogeral = registrogeral;
        this.rua = rua;
        this.numero = numero;
        this.balneario = balneario;
        this.cidade = cidade;
        this.usuarioId = usuarioId;
        this.cargoId = cargoId;
    }

    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone01() {
        return telefone01;
    }

    public void setTelefone01(String telefone01) {
        this.telefone01 = telefone01;
    }

    public String getTelefone02() {
        return telefone02;
    }

    public void setTelefone02(String telefone02) {
        this.telefone02 = telefone02;
    }

    public String getDataadmissao() {
        return dataadmissao;
    }

    public void setDataadmissao(String dataadmissao) {
        this.dataadmissao = dataadmissao;
    }

    public String getDataDemissao() {
        return dataDemissao;
    }

    public void setDataDemissao(String dataDemissao) {
        this.dataDemissao = dataDemissao;
    }

    public String getNumcarteiraTrabalho() {
        return numcarteiraTrabalho;
    }

    public void setNumcarteiraTrabalho(String numcarteiraTrabalho) {
        this.numcarteiraTrabalho = numcarteiraTrabalho;
    }

    public String getRegistrogeral() {
        return registrogeral;
    }

    public void setRegistrogeral(String registrogeral) {
        this.registrogeral = registrogeral;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getBalneario() {
        return balneario;
    }

    public void setBalneario(String balneario) {
        this.balneario = balneario;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(String usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getCargoId() {
        return cargoId;
    }

    public void setCargoId(String cargoId) {
        this.cargoId = cargoId;
    }

    

   public void cadastroFuncionario(){
  
       
        
        System.out.println("Idfuncionario: "+ idFuncionario);
        System.out.println("Nome: "+ nome);
        System.out.println("Telefone 01: "+ telefone01);
        System.out.println("Telefone 02: "+ telefone02);
        System.out.println("Data de Admissao: "+ dataadmissao);
        System.out.println("Data de Demissao: "+ dataDemissao);
        System.out.println("Numero Carteira Trabalho: "+ numcarteiraTrabalho);
        System.out.println("Registro Geral: "+ registrogeral);
        System.out.println("Rua: "+ rua);
        System.out.println("Numero: "+ numero);
        System.out.println("Balneario: "+ balneario);
        System.out.println("Cidade: "+ cidade);
        System.out.println("usuarioId: "+ usuarioId);
        System.out.println("cargoId: "+ cargoId);
        System.out.println("\n");
        
        
    
    }
    public void linha(){
    System.out.print("_____________________________________________________________________________________________________________________________________________\n\n");
    }


    
}
