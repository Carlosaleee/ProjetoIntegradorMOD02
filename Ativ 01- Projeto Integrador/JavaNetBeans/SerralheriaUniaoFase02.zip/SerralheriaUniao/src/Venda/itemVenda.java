package Venda;

    public class itemVenda {
            
        private String nomeEsquadria;
        private int quantidade;
        private double valorMetroQuadrado;
        private double altura;
        private double largura;
        private double valorUnitario;
        private double subTotal;
        private int vendaid;
        private int esquadriaId;

    public itemVenda(String nomeEsquadria, int quantidade, double valorMetroQuadrado, double altura, double largura, double valorUnitario, double subTotal, int vendaid, int esquadriaId) {
        this.nomeEsquadria = nomeEsquadria;
        this.quantidade = quantidade;
        this.valorMetroQuadrado = valorMetroQuadrado;
        this.altura = altura;
        this.largura = largura;
        this.valorUnitario = valorUnitario;
        this.subTotal = subTotal;
        this.vendaid = vendaid;
        this.esquadriaId = esquadriaId;
    }

    public String getNomeEsquadria() {
        return nomeEsquadria;
    }

    public void setNomeEsquadria(String nomeEsquadria) {
        this.nomeEsquadria = nomeEsquadria;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getValorMetroQuadrado() {
        return valorMetroQuadrado;
    }

    public void setValorMetroQuadrado(double valorMetroQuadrado) {
        this.valorMetroQuadrado = valorMetroQuadrado;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getLargura() {
        return largura;
    }

    public void setLargura(double largura) {
        this.largura = largura;
    }

    public double getValorUnitario() {
        return valorUnitario;
    }

    public void setValorUnitario(double valorUnitario) {
        this.valorUnitario = valorUnitario;
    }

    public double getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(double subTotal) {
        this.subTotal = subTotal;
    }

    public int getVendaid() {
        return vendaid;
    }

    public void setVendaid(int vendaid) {
        this.vendaid = vendaid;
    }

    public int getEsquadriaId() {
        return esquadriaId;
    }

    public void setEsquadriaId(int esquadriaId) {
        this.esquadriaId = esquadriaId;
    }
        
        


}
