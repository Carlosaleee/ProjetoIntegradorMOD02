package Venda;

import java.util.Date;

    public class Venda {
        
        private int idVenda;
        private Date dataVenda;
        private Date dataEntrega;
        private double valorTotal;
        private int clienteId;
        private int funcionarioId;	

    public Venda(int idVenda, Date dataVenda, Date dataEntrega, Double valorTotal, int clienteId, int funcionarioId) {
        this.idVenda = idVenda;
        this.dataVenda = dataVenda;
        this.dataEntrega = dataEntrega;
        this.valorTotal = valorTotal;
        this.clienteId = clienteId;
        this.funcionarioId = funcionarioId;
    }

    public int getIdVenda() {
        return idVenda;
    }

    public void setIdVenda(int idVenda) {
        this.idVenda = idVenda;
    }

    public Date getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(Date dataVenda) {
        this.dataVenda = dataVenda;
    }

    public Date getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(Date dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public Double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(Double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public int getClienteId() {
        return clienteId;
    }

    public void setClienteId(int clienteId) {
        this.clienteId = clienteId;
    }

    public int getFuncionarioId() {
        return funcionarioId;
    }

    public void setFuncionarioId(int funcionarioId) {
        this.funcionarioId = funcionarioId;
    }
        
        


}
