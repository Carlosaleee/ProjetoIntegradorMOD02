package Venda;

import java.util.Date;

    public class formaPagamento {
        
        private int idPagamento;
        private Date dataPagamento;
        private char tipoPagamento;
        private String numeroCartao;
        private int numeroParcelas;
        private int vendaid;

    public formaPagamento(int idPagamento, Date dataPagamento, char tipoPagamento, String numeroCartao, int numeroParcelas, int vendaid) {
        this.idPagamento = idPagamento;
        this.dataPagamento = dataPagamento;
        this.tipoPagamento = tipoPagamento;
        this.numeroCartao = numeroCartao;
        this.numeroParcelas = numeroParcelas;
        this.vendaid = vendaid;
    }

    public int getIdPagamento() {
        return idPagamento;
    }

    public void setIdPagamento(int idPagamento) {
        this.idPagamento = idPagamento;
    }

    public Date getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(Date dataPagamento) {
        this.dataPagamento = dataPagamento;
    }

    public char getTipoPagamento() {
        return tipoPagamento;
    }

    public void setTipoPagamento(char tipoPagamento) {
        this.tipoPagamento = tipoPagamento;
    }

    public String getNumeroCartao() {
        return numeroCartao;
    }

    public void setNumeroCartao(String numeroCartao) {
        this.numeroCartao = numeroCartao;
    }

    public int getNumeroParcelas() {
        return numeroParcelas;
    }

    public void setNumeroParcelas(int numeroParcelas) {
        this.numeroParcelas = numeroParcelas;
    }

    public int getVendaid() {
        return vendaid;
    }

    public void setVendaid(int vendaid) {
        this.vendaid = vendaid;
    }
        
        

    
}
