package Cliente;

    public class cliente {
        
        private String idCliente;
        private String nome;
        private String telefone01;
        private String telefone02;
        private String cpf;
        private String rua;
        private String numero;
        private String balneario;
        private String cidade;

    public cliente(String idCliente, String nome, String telefone01, String telefone02, String cpf, String rua, String numero, String balneario, String cidade) {
        this.idCliente = idCliente;
        this.nome = nome;
        this.telefone01 = telefone01;
        this.telefone02 = telefone02;
        this.cpf = cpf;
        this.rua = rua;
        this.numero = numero;
        this.balneario = balneario;
        this.cidade = cidade;
    }

    public String getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone01() {
        return telefone01;
    }

    public void setTelefone01(String telefone01) {
        this.telefone01 = telefone01;
    }

    public String getTelefone02() {
        return telefone02;
    }

    public void setTelefone02(String telefone02) {
        this.telefone02 = telefone02;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getBalneario() {
        return balneario;
    }

    public void setBalneario(String balneario) {
        this.balneario = balneario;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public void cadastroCliente(){
        System.out.println("IdCliente: "+ idCliente);
        System.out.println("Nome: "+ nome);
        System.out.println("Telefone 01: "+ telefone01);
        System.out.println("Telefone 02: "+ telefone02);
        System.out.println("Numero Cpf: "+ cpf);
        System.out.println("Rua: "+ rua);
        System.out.println("Numero: "+ numero);
        System.out.println("Balneario: "+ balneario);
        System.out.println("Cidade: "+ cidade);
        System.out.println("\n"); 
    
}   
        
 
}
