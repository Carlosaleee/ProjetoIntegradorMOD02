 package financeiro.Bens;

    public class Produto {
    
        private String produto;
        private String quantidade;
        private String valorMetroQuadrado;
        private String altura;
        private String largura;
        private String valorUnitario;
        private String vendaId;
        private String esquadriaId;
        private String subTotal;

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }

    public String getValorMetroQuadrado() {
        return valorMetroQuadrado;
    }

    public void setValorMetroQuadrado(String valorMetroQuadrado) {
        this.valorMetroQuadrado = valorMetroQuadrado;
    }

    public String getAltura() {
        return altura;
    }

    public void setAltura(String altura) {
        this.altura = altura;
    }

    public String getLargura() {
        return largura;
    }

    public void setLargura(String largura) {
        this.largura = largura;
    }

    public String getValorUnitario() {
        return valorUnitario;
    }

    public void setValorUnitario(String valorUnitario) {
        this.valorUnitario = valorUnitario;
    }

    public String getVendaId() {
        return vendaId;
    }

    public void setVendaId(String vendaId) {
        this.vendaId = vendaId;
    }

    public String getEsquadriaId() {
        return esquadriaId;
    }

    public void setEsquadriaId(String esquadriaId) {
        this.esquadriaId = esquadriaId;
    }

    public String getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(String subTotal) {
        this.subTotal = subTotal;
    }

}
