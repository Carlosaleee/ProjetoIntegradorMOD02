package esquadria.Beans;

    public class Distribuidor {
    
        private int idDistribuidor;
        private String nomeEmpresa;
        private String cnpj;
        private String telefone01;
        private String telefone02;
        private String setor;
        private String responsavel;
        private String cidade;
        private String Estado;

    public Distribuidor(int idDistribuidor, String nomeEmpresa, String cnpj, String telefone01, String telefone02, String setor, String responsavel, String cidade, String Estado) {
        this.idDistribuidor = idDistribuidor;
        this.nomeEmpresa = nomeEmpresa;
        this.cnpj = cnpj;
        this.telefone01 = telefone01;
        this.telefone02 = telefone02;
        this.setor = setor;
        this.responsavel = responsavel;
        this.cidade = cidade;
        this.Estado = Estado;
    }

    public int getIdDistribuidor() {
        return idDistribuidor;
    }

    public void setIdDistribuidor(int idDistribuidor) {
        this.idDistribuidor = idDistribuidor;
    }

    public String getNomeEmpresa() {
        return nomeEmpresa;
    }

    public void setNomeEmpresa(String nomeEmpresa) {
        this.nomeEmpresa = nomeEmpresa;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getTelefone01() {
        return telefone01;
    }

    public void setTelefone01(String telefone01) {
        this.telefone01 = telefone01;
    }

    public String getTelefone02() {
        return telefone02;
    }

    public void setTelefone02(String telefone02) {
        this.telefone02 = telefone02;
    }

    public String getSetor() {
        return setor;
    }

    public void setSetor(String setor) {
        this.setor = setor;
    }

    public String getResponsavel() {
        return responsavel;
    }

    public void setResponsavel(String responsavel) {
        this.responsavel = responsavel;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String Estado) {
        this.Estado = Estado;
    }

    
    
    public void cadastroDistribuidorAluminio(){
        System.out.println("idDistribuidorAluminio: "+ idDistribuidor);
        System.out.println("Nome da Empresa: "+ nomeEmpresa);
        System.out.println("Cnpj: "+ cnpj);
        System.out.println("Telefone01: "+ telefone01);
        System.out.println("Telefone02: "+ telefone01);
        System.out.println("Setor: "+ setor);
        System.out.println("Responsavel: "+ responsavel);
        System.out.println("Cidade: "+ cidade);
        System.out.println("Estado: "+ Estado);
        
        System.out.println("\n"); 
    
    }   

}