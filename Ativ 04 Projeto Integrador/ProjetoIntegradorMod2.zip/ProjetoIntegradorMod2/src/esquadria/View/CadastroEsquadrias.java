/**
* @author Carlos Alexandre Da Silva
* @version 1.0
* @since Primeira versão
*/

package esquadria.View;

import esquadria.Beans.Esquadria;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class CadastroEsquadrias extends javax.swing.JFrame {

    private final String[] tableColumns = { "idEsquadria","Nome da Esquadria", "Descrição", "Preço", "Distribuidorid"};
    DefaultTableModel tableModel = new DefaultTableModel(tableColumns, 0);
    private ArrayList<Esquadria> listaEsquadrias = new ArrayList<>();

    public CadastroEsquadrias() {

        initComponents();
        geraAcessebilidade();
        setTitle("Cadastro de Esquadrias");
        
                        listaEsquadrias.add(new Esquadria("1","Tela de Proteção","Tela de Proteção contra Insetos","160.00","1")); 
                        listaEsquadrias.add(new Esquadria("2","Box de Vidro","Box de Vidro Temperado para Banho","380.00","3")); 
                        listaEsquadrias.add(new Esquadria("3","Abrigo de Pia em Aluminio","Abrigo para Pia de Cozinha","500.00","1")); 
                        listaEsquadrias.add(new Esquadria("4", "Abrigo de Pia em Acrilico","Abrigo para Pia de Cozinha","300.00","2")); 
                        listaEsquadrias.add(new Esquadria("5", "Grades de Proteção","Grades de Proteção com Ferro","450.00","1")); 
                        listaEsquadrias.add(new Esquadria("6","Porta de Tela","Porta de Tela de Proteção contra Insetos","550.00","2")); 
                        listaEsquadrias.add(new Esquadria("7","Porta de Giro Fechada","Porta de Giro fechada em Paletas","640.00","1")); 
                        listaEsquadrias.add(new Esquadria("8","Portão Fechado Aluminio Branco","Portão de Alumínio Deslizante","750.00","1")); 
                        listaEsquadrias.add(new Esquadria("9","Portão Fechado Aluminio Bronze","Portão de Alumínio Deslizante","800.00","2")); 
                        listaEsquadrias.add(new Esquadria("10","Portão Fechado Lambril Simples","Portão de Alumínio Deslizante","750.00","4")); 
                        listaEsquadrias.add(new Esquadria("11","Portão Fechado Lambril Duplo","Portão de Alumínio Deslizante","830.00","4")); 
                        listaEsquadrias.add(new Esquadria("12","Portão de Regua","Portão de Alumínio Deslizante","750.00","1")); 
                        listaEsquadrias.add(new Esquadria("13","Portão de Tubo Simples","Portão de Alumínio Deslizante","690.00","1")); 
                        listaEsquadrias.add(new Esquadria("14","Janela Linha Suprema 2 folhas","Janela de Alumínio Branco com 2 folhas e vidro","600.00","3")); 
                        listaEsquadrias.add(new Esquadria("15","Janela Linha Suprema 4 folhas","Janela de Alumínio Branco com 4 folhas e vidro","800.00","4")); 
                        listaEsquadrias.add(new Esquadria("16","Janela Linha Vidro Temperado 4 folhas","Janela de Vidro Temperado com 4 folhas","900.00","3")); 
                        listaEsquadrias.add(new Esquadria("17","Portão Social Fechado","Portão Social 2.10 x 0.90","950.00","1")); 
                        listaEsquadrias.add(new Esquadria("18","Veneziana Linha Suprema 3 folhas","Janela para Quarto 3 folhas Deslizantes","800.00","1")); 
                        listaEsquadrias.add(new Esquadria("19","Veneziana Linha Suprema 6 folhas","Janela para Quarto 6 folhas Deslizantes","950.00","1")); 
                        listaEsquadrias.add(new Esquadria("20","Vitro Basculhante","Vitro Basculante para Banheiro","450.00","1")); 
                        
        
        atualizarTabela();
    }

    public void geraAcessebilidade() {

        btnCadastrar.setMnemonic(KeyEvent.VK_C);
        btnLimpar.setMnemonic(KeyEvent.VK_L);
        btnPesquisar.setMnemonic(KeyEvent.VK_P);
        btnVoltar.setMnemonic(KeyEvent.VK_V);
        btnExcluir.setMnemonic(KeyEvent.VK_E);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        jLabel1 = new javax.swing.JLabel();
        jLayeredPane3 = new javax.swing.JLayeredPane();
        jLayeredPane24 = new javax.swing.JLayeredPane();
        lblNome2 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        txtNomeEsquadria = new javax.swing.JTextField();
        txtPreco = new javax.swing.JTextField();
        txtDistribuidorId = new javax.swing.JTextField();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtDescricao = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        txtIdEsquadria = new javax.swing.JTextField();
        btnCadastrar = new javax.swing.JButton();
        btnPesquisar = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnVoltar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblEsquadrias = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLayeredPane1.setBackground(new java.awt.Color(0, 0, 0));
        jLayeredPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jLayeredPane1.setForeground(new java.awt.Color(0, 0, 0));

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Cadastro Esquadrias");

        jLayeredPane1.setLayer(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane1Layout = new javax.swing.GroupLayout(jLayeredPane1);
        jLayeredPane1.setLayout(jLayeredPane1Layout);
        jLayeredPane1Layout.setHorizontalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane1Layout.createSequentialGroup()
                .addGap(169, 169, 169)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(169, 169, 169))
        );
        jLayeredPane1Layout.setVerticalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jLayeredPane24.setBackground(new java.awt.Color(0, 0, 0));
        jLayeredPane24.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jLayeredPane24.setForeground(new java.awt.Color(0, 0, 0));

        lblNome2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblNome2.setForeground(new java.awt.Color(0, 0, 0));
        lblNome2.setText("Nome Esquadria:");

        jLabel40.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(0, 0, 0));
        jLabel40.setText("Descrição :");

        jLabel41.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(0, 0, 0));
        jLabel41.setText("Preço :");

        jLabel47.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(0, 0, 0));
        jLabel47.setText("DistribuidorId :");

        txtNomeEsquadria.setForeground(new java.awt.Color(0, 0, 0));
        txtNomeEsquadria.setToolTipText("Digite o Nome");
        txtNomeEsquadria.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        txtNomeEsquadria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeActionPerformed(evt);
            }
        });

        txtPreco.setForeground(new java.awt.Color(0, 0, 0));
        txtPreco.setToolTipText("Digite o Telefone. Utilize o formato (XX)XXXXX-XXXX");
        txtPreco.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        txtPreco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefone02ActionPerformed(evt);
            }
        });

        txtDistribuidorId.setForeground(new java.awt.Color(0, 0, 0));
        txtDistribuidorId.setToolTipText("Digite a Cidade");
        txtDistribuidorId.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLabel48.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(255, 0, 51));
        jLabel48.setText("Dados da Esquadria :");

        jLabel49.setFont(new java.awt.Font("Arial Black", 1, 16)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(255, 0, 51));
        jLabel49.setText("Preencha o Cadastro :");
        jLabel49.setToolTipText("Preencha o Formulário");

        txtDescricao.setColumns(20);
        txtDescricao.setRows(5);
        txtDescricao.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jScrollPane2.setViewportView(txtDescricao);

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("idEsquadria :");

        txtIdEsquadria.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLayeredPane24.setLayer(lblNome2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane24.setLayer(jLabel40, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane24.setLayer(jLabel41, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane24.setLayer(jLabel47, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane24.setLayer(txtNomeEsquadria, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane24.setLayer(txtPreco, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane24.setLayer(txtDistribuidorId, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane24.setLayer(jLabel48, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane24.setLayer(jLabel49, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane24.setLayer(jScrollPane2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane24.setLayer(jLabel2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane24.setLayer(txtIdEsquadria, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane24Layout = new javax.swing.GroupLayout(jLayeredPane24);
        jLayeredPane24.setLayout(jLayeredPane24Layout);
        jLayeredPane24Layout.setHorizontalGroup(
            jLayeredPane24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane24Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jLayeredPane24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jLayeredPane24Layout.createSequentialGroup()
                        .addGroup(jLayeredPane24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblNome2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jLayeredPane24Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addGroup(jLayeredPane24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel41)
                                    .addComponent(jLabel47)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel40))))
                        .addGroup(jLayeredPane24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jLayeredPane24Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtIdEsquadria, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(387, 387, 387))
                            .addGroup(jLayeredPane24Layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addGroup(jLayeredPane24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNomeEsquadria, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtDistribuidorId, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtPreco, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane2))
                                .addGap(0, 83, Short.MAX_VALUE))))
                    .addGroup(jLayeredPane24Layout.createSequentialGroup()
                        .addGroup(jLayeredPane24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel49)
                            .addComponent(jLabel48))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jLayeredPane24Layout.setVerticalGroup(
            jLayeredPane24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel49)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel48)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jLayeredPane24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIdEsquadria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jLayeredPane24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeEsquadria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNome2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jLayeredPane24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jLayeredPane24Layout.createSequentialGroup()
                        .addComponent(jLabel40)
                        .addGap(46, 46, 46))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jLayeredPane24Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(jLayeredPane24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel41)
                    .addComponent(txtPreco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jLayeredPane24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtDistribuidorId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel47))
                .addGap(41, 41, 41))
        );

        btnCadastrar.setBackground(new java.awt.Color(0, 0, 0));
        btnCadastrar.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnCadastrar.setForeground(new java.awt.Color(255, 255, 255));
        btnCadastrar.setText("Cadastrar");
        btnCadastrar.setToolTipText("Cadastra a Esquadria");
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });

        btnPesquisar.setBackground(new java.awt.Color(0, 0, 0));
        btnPesquisar.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        btnPesquisar.setForeground(new java.awt.Color(255, 255, 255));
        btnPesquisar.setText("Pesquisar");
        btnPesquisar.setToolTipText("Pesquisa a Esquadria");
        btnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarActionPerformed(evt);
            }
        });

        btnLimpar.setBackground(new java.awt.Color(0, 0, 0));
        btnLimpar.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        btnLimpar.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpar.setText("Limpar");
        btnLimpar.setToolTipText("Limpa os Campos Digitados");
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        btnExcluir.setBackground(new java.awt.Color(0, 0, 0));
        btnExcluir.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        btnExcluir.setForeground(new java.awt.Color(255, 255, 255));
        btnExcluir.setText("Excluir");
        btnExcluir.setToolTipText("Exclui a Esquadria");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnVoltar.setBackground(new java.awt.Color(0, 0, 0));
        btnVoltar.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        btnVoltar.setForeground(new java.awt.Color(255, 255, 255));
        btnVoltar.setText("Voltar");
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        tblEsquadrias.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        tblEsquadrias.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "idEsquadria", "Nome da Esquadria", "Descrição", "Preço", "DistribuidorId"
            }
        ));
        jScrollPane1.setViewportView(tblEsquadrias);

        jLayeredPane3.setLayer(jLayeredPane24, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane3.setLayer(btnCadastrar, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane3.setLayer(btnPesquisar, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane3.setLayer(btnLimpar, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane3.setLayer(btnExcluir, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane3.setLayer(btnVoltar, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane3.setLayer(jScrollPane1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane3Layout = new javax.swing.GroupLayout(jLayeredPane3);
        jLayeredPane3.setLayout(jLayeredPane3Layout);
        jLayeredPane3Layout.setHorizontalGroup(
            jLayeredPane3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jLayeredPane3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLayeredPane24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jLayeredPane3Layout.createSequentialGroup()
                .addComponent(btnCadastrar)
                .addGap(28, 28, 28)
                .addComponent(btnPesquisar)
                .addGap(29, 29, 29)
                .addComponent(btnLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jLayeredPane3Layout.setVerticalGroup(
            jLayeredPane3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jLayeredPane3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLayeredPane24, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jLayeredPane3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCadastrar)
                    .addComponent(btnPesquisar)
                    .addComponent(btnLimpar)
                    .addComponent(btnExcluir)
                    .addComponent(btnVoltar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(51, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLayeredPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLayeredPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 655, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        excluirEsquadria(getPosicaoEsquadria());
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarActionPerformed
        
         String nomeBusca = JOptionPane.showInputDialog(null, "Digite o nome da Esquadria que deseja pesquisar: ");
              boolean EsquadriaEncontrada = false;

        for (Esquadria esquadria : listaEsquadrias) {
            if (esquadria.getNomeEsquadria().equalsIgnoreCase(nomeBusca)) {
                String mensagem = "ID Esquadria :" + esquadria.getIdEsquadria() + "\n"
                        + "Nome da Esquadria :" + esquadria.getNomeEsquadria() + "\n"
                        + "Descrição :" + esquadria.getDescricao() + "\n"
                        + "Preço :" + esquadria.getPreco() + "\n"
                        + "DistribuidorId :" + esquadria.getDistribuidorId() + "\n"
                        ;

                JOptionPane.showMessageDialog(null, mensagem);
                EsquadriaEncontrada = true;

            }
        }

        if (!EsquadriaEncontrada) {
            JOptionPane.showMessageDialog(null, "Esquadria não encontrada.");
        }
    }//GEN-LAST:event_btnPesquisarActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed

        if (!emptyFields()) {

            Esquadria esquadria = getEsquadria();

            if (esquadria != null) {

                inserirEsquadria(esquadria);
                // Nome do arquivo onde os registros serão salvos
            }

            txtIdEsquadria.setText("");
            txtNomeEsquadria.setText("");
            txtDescricao.setText("");
            txtPreco.setText("");
            txtDistribuidorId.setText("");

            txtNomeEsquadria.requestFocus();
        }
    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void txtTelefone02ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefone02ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefone02ActionPerformed

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed

        txtIdEsquadria.setText("");
        txtNomeEsquadria.setText("");
        txtDescricao.setText("");
        txtPreco.setText("");
        txtDistribuidorId.setText("");

        txtNomeEsquadria.requestFocus();
    }//GEN-LAST:event_btnLimparActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CadastroEsquadrias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CadastroEsquadrias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CadastroEsquadrias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CadastroEsquadrias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroEsquadrias().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnPesquisar;
    private javax.swing.JButton btnVoltar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JLayeredPane jLayeredPane24;
    private javax.swing.JLayeredPane jLayeredPane3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblNome2;
    private javax.swing.JTable tblEsquadrias;
    private javax.swing.JTextArea txtDescricao;
    private javax.swing.JTextField txtDistribuidorId;
    private javax.swing.JTextField txtIdEsquadria;
    private javax.swing.JTextField txtNomeEsquadria;
    private javax.swing.JTextField txtPreco;
    // End of variables declaration//GEN-END:variables

    // set
    private boolean emptyFields() {
        /*
      * Variável empty assume “true” por padrão e só vai mudar o seu estado
      * após verificarmos se todos os campos estão preenchidos. É ela que
      * retornamos ao final do método.
         */
        boolean empty = true;

        if (txtIdEsquadria.getText().trim().isEmpty()) {

           JOptionPane.showMessageDialog(rootPane, "ATENÇÃO! idEsquadria não pode ser vazio.");
        } else if (txtNomeEsquadria.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(rootPane, "ATENÇÃO! Nome da Esquadria não pode ser vazio.");
        } else if (txtDescricao.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(rootPane, "ATENÇÃO! Descrição não pode ser vazio.");
        } else if (txtPreco.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(rootPane, "ATENÇÃO! Preço não pode ser vazio.");
        } else if (txtDistribuidorId.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(rootPane, "ATENÇÃO! DistribuidorId  não pode ser vazio.");
        } else {

            empty = false;
        }

        return empty;
    }

    private Esquadria getEsquadria() {

        if (!emptyFields()) {

            Esquadria esquadria = new Esquadria("idEsquadria","Nome Esquadria","Descrição","Preço","Distribuidora");

            esquadria.setIdEsquadria(txtIdEsquadria.getText());
            esquadria.setNomeEsquadria(txtNomeEsquadria.getText());
            esquadria.setDescricao(txtDescricao.getText());
            esquadria.setPreco(txtPreco.getText());
            esquadria.setDistribuidorId(txtDistribuidorId.getText());

            JOptionPane.showMessageDialog(null, "Os seguintes dados foram cadastrados com sucesso: \n"
                    + "\nIdEsquadria: " + txtIdEsquadria.getText()
                    + "\nNome da Esquadria: " + txtNomeEsquadria.getText()
                    + "\nDescrição: " + txtDescricao.getText()
                    + "\nPreço: " + txtPreco.getText()
                    + "\nDistribuidora: " + txtDistribuidorId.getText()
            );

            return esquadria;

        } else {
            JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos corretamente.");
        }
        return null;
    }

    private void inserirEsquadria(Esquadria esquadria) {
        listaEsquadrias.add(esquadria);

        atualizarTabela();

    }

    // set
    private void atualizarTabela() {

        if (!listaEsquadrias.isEmpty()) {

            Esquadria esquadria;
            tableModel = new DefaultTableModel(tableColumns, 0);
            for (int i = 0; i < listaEsquadrias.size(); i++) {

                esquadria = listaEsquadrias.get(i);

                String[] rowData = {
                    esquadria.getIdEsquadria(),
                    esquadria.getNomeEsquadria(),
                    esquadria.getDescricao(),
                    esquadria.getPreco(),
                    esquadria.getDistribuidorId()
                };
                tableModel.addRow(rowData);
            }

            tblEsquadrias.setModel(tableModel);
        } else {

            tableModel = new DefaultTableModel(tableColumns, 0);
            tblEsquadrias.setModel(tableModel);
        }
    }

    // Set
    private int getPosicaoEsquadria() {

        int posEsquadria = tblEsquadrias.getSelectedRow();
        if (posEsquadria == -1) {
            JOptionPane.showMessageDialog(rootPane, "Selecione um Registro");
        }
        return posEsquadria;
    }

    // set
    private void excluirEsquadria(int posEsquadria) {

        if (posEsquadria >= 0) {

            String[] options = {"Sim", "Não"};

            int deletar = JOptionPane.showOptionDialog(
                    rootPane,
                    "Tem certeza que deseja excluir o Registro ?",
                    "Exclusão, Registro de Esquadria.",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    options,
                    options[0]
            );
            if (deletar == 0) {

                listaEsquadrias.remove(posEsquadria);
                atualizarTabela();
            } else {
                /*
             * Limpar a seleção pois o usuário cancelou a exclusão.
                 */
                tblEsquadrias.clearSelection();
            }
        }
    }

}
