package administrativo.Beans;

    public class Cargo {
        
    private int idCargo;
    private String Cargo;
    private String descricao;
    private String salario;

    public Cargo(int idCargo, String Cargo, String descricao, String salario) {
        this.idCargo = idCargo;
        this.Cargo = Cargo;
        this.descricao = descricao;
        this.salario = salario;
    }

    public int getIdCargo() {
        return idCargo;
    }

    public void setIdCargo(int idCargo) {
        this.idCargo = idCargo;
    }

    public String getCargo() {
        return Cargo;
    }

    public void setCargo(String Cargo) {
        this.Cargo = Cargo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getSalario() {
        return salario;
    }

    public void setSalario(String salario) {
        this.salario = salario;
    }
    
    

       
}

