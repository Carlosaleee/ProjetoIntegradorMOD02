/**
* @author Carlos Alexandre Da Silva
* @version 1.0
* @since Primeira versão
*/

package cliente.View;

import administrativo.Beans.Funcionario;
import cliente.Beans.Cliente;
import java.awt.event.KeyEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class CadastroClientes extends javax.swing.JFrame {
    
        private final String[] tableColumns = {"idCliente", "Nome", "Telefone 01", "Telefone 02", "CPF", "Rua", "Numero", "Balneario", "Cidade"};
        DefaultTableModel tableModel = new DefaultTableModel(tableColumns, 0);
        private ArrayList<Cliente> listaClientes = new ArrayList<>(); 
        

    public CadastroClientes() {
        initComponents();
        geraAcessbilidade();
        setTitle("Serralheria União");
        
                            listaClientes.add(new Cliente(1, "Adriano de Souza", "11 96214 6625", null, "29043921068", "Rua Franca","470", "Bal. Icarai", "Ilha Comprida"));
                            listaClientes.add(new Cliente(2, "Gabriel Medina", "13 99876 6578", null, "22724372069", "Rua Franca","470", "Bal. Icarai", "Ilha Comprida"));
                            listaClientes.add(new Cliente(3, "Felipe Toledo", "13 99876 6578", null, "59610341004", "Rua Casa Verde","60", "Bal. Leão de Iguape", "Ilha Comprida"));
                            listaClientes.add(new Cliente(4, "Italo Ferreira", "13 99777 0301", null, "89476252057", "Rua da Garças","38", "Bal. Mar e Sol", "Ilha Comprida"));
                            listaClientes.add(new Cliente(5, "Raissa Leal", "15 99757 6618", null, "41507587007", "Rua das Papoulas","987", "Bal. Porto Velho", "Ilha Comprida"));
                            listaClientes.add(new Cliente(6, "Peterson Rosa", "13 99764 7676", null, "95837653090", "Rua Cascata","160", "Bal. Atlantico", "Ilha Comprida"));
                            listaClientes.add(new Cliente(7, "Pamela Rosa", "11 99876 9956", null, "76798976034", "Rua Rio Grande do Norte","540", "Bal. Adriana", "Ilha Comprida"));
                            listaClientes.add(new Cliente(8, "Gustavo Borges", "67 99876 4433", null, "49008644045", "Rua Cuiaba","150", "Bal. Adriana", "Ilha Comprida"));
                            listaClientes.add(new Cliente(9, "Leticia Sabatela", "15 99764 8201", null, "29346675020", "Rua Cuiaba","150", "Bal. Adriana", "Ilha Comprida"));
                            listaClientes.add(new Cliente(10, "Fabio Gouveia", "11 94910 5239", null, "44450569016", "Rua Tino Gonsalves Dias","549", "Bal. Britania", "Ilha Comprida"));
                                
                            atualizarTabela();
    }
    
    public void geraAcessbilidade(){
        
        btnCadastrar.setMnemonic(KeyEvent.VK_C);
        btnLimpar.setMnemonic(KeyEvent.VK_L);
        btnPesquisar.setMnemonic(KeyEvent.VK_P);
        btnVoltar.setMnemonic(KeyEvent.VK_V);
        btnExcluir.setMnemonic(KeyEvent.VK_E);
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLayeredPane19 = new javax.swing.JLayeredPane();
        jLabel19 = new javax.swing.JLabel();
        jLayeredPane22 = new javax.swing.JLayeredPane();
        lblNome = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        txtTelefone01 = new javax.swing.JTextField();
        txtTelefone02 = new javax.swing.JTextField();
        txtCPF = new javax.swing.JTextField();
        txtRua = new javax.swing.JTextField();
        txtNumero = new javax.swing.JTextField();
        txtBalneario = new javax.swing.JTextField();
        txtCidade = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        txtIdCliente = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        btnCadastrar = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        btnPesquisar = new javax.swing.JButton();
        btnVoltar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblClientes = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLayeredPane19.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLabel19.setFont(new java.awt.Font("Arial Black", 1, 32)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 0));
        jLabel19.setText("Cadastro de Cliente");

        jLayeredPane19.setLayer(jLabel19, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane19Layout = new javax.swing.GroupLayout(jLayeredPane19);
        jLayeredPane19.setLayout(jLayeredPane19Layout);
        jLayeredPane19Layout.setHorizontalGroup(
            jLayeredPane19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane19Layout.createSequentialGroup()
                .addGap(155, 155, 155)
                .addComponent(jLabel19)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jLayeredPane19Layout.setVerticalGroup(
            jLayeredPane19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jLayeredPane19Layout.createSequentialGroup()
                .addComponent(jLabel19)
                .addGap(0, 9, Short.MAX_VALUE))
        );

        jLayeredPane22.setBackground(new java.awt.Color(0, 0, 0));
        jLayeredPane22.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jLayeredPane22.setForeground(new java.awt.Color(0, 0, 0));

        lblNome.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblNome.setForeground(new java.awt.Color(0, 0, 0));
        lblNome.setText("Nome:");

        jLabel20.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 0, 0));
        jLabel20.setText("Telefone 01 :");

        jLabel21.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 0, 0));
        jLabel21.setText("Telefone  02 :");

        jLabel22.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 0, 0));
        jLabel22.setText("CPF :");

        jLabel24.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 0, 51));
        jLabel24.setText("Endereço :");

        jLabel25.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(0, 0, 0));
        jLabel25.setText("Rua :");

        jLabel26.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(0, 0, 0));
        jLabel26.setText("Numero :");

        jLabel27.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(0, 0, 0));
        jLabel27.setText("Balneario :");

        jLabel28.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(0, 0, 0));
        jLabel28.setText("Cidade :");

        txtNome.setForeground(new java.awt.Color(0, 0, 0));
        txtNome.setToolTipText("Digite o Nome");
        txtNome.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        txtNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeActionPerformed(evt);
            }
        });

        txtTelefone01.setForeground(new java.awt.Color(0, 0, 0));
        txtTelefone01.setToolTipText("Digite o Numero do Telefone. Utilize o formato  (XX)XXXXX-XXXX");
        txtTelefone01.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        txtTelefone01.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefone01ActionPerformed(evt);
            }
        });

        txtTelefone02.setForeground(new java.awt.Color(0, 0, 0));
        txtTelefone02.setToolTipText("Digite o Telefone. Utilize o formato (XX)XXXXX-XXXX");
        txtTelefone02.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        txtTelefone02.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefone02ActionPerformed(evt);
            }
        });

        txtCPF.setForeground(new java.awt.Color(0, 0, 0));
        txtCPF.setToolTipText("Digite o numero da CPF. Utilize o Formato XXX.XXX.XXX-XX");
        txtCPF.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        txtRua.setForeground(new java.awt.Color(0, 0, 0));
        txtRua.setToolTipText("Digite o Nome da Rua  ");
        txtRua.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        txtRua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRuaActionPerformed(evt);
            }
        });

        txtNumero.setForeground(new java.awt.Color(0, 0, 0));
        txtNumero.setToolTipText("Digite o Numero da Residência");
        txtNumero.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        txtBalneario.setForeground(new java.awt.Color(0, 0, 0));
        txtBalneario.setToolTipText("Digite o Balneario");
        txtBalneario.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        txtCidade.setForeground(new java.awt.Color(0, 0, 0));
        txtCidade.setToolTipText("Digite a Cidade");
        txtCidade.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLabel34.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 51, 0));
        jLabel34.setText("Dados Pessoais :");

        txtIdCliente.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        txtIdCliente.setForeground(new java.awt.Color(0, 0, 0));
        txtIdCliente.setToolTipText("Digite o Id do Cliente");
        txtIdCliente.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLabel35.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("IdCliente :");

        jLabel33.setFont(new java.awt.Font("Arial Black", 1, 16)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 0, 51));
        jLabel33.setText("Preencha o Formulário :");
        jLabel33.setToolTipText("Preencha o Formulário");

        jLayeredPane22.setLayer(lblNome, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(jLabel20, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(jLabel21, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(jLabel22, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(jLabel24, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(jLabel25, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(jLabel26, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(jLabel27, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(jLabel28, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(txtNome, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(txtTelefone01, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(txtTelefone02, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(txtCPF, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(txtRua, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(txtNumero, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(txtBalneario, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(txtCidade, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(jLabel34, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(txtIdCliente, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(jLabel35, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane22.setLayer(jLabel33, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane22Layout = new javax.swing.GroupLayout(jLayeredPane22);
        jLayeredPane22.setLayout(jLayeredPane22Layout);
        jLayeredPane22Layout.setHorizontalGroup(
            jLayeredPane22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane22Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jLayeredPane22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jLayeredPane22Layout.createSequentialGroup()
                        .addComponent(jLabel24)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jLayeredPane22Layout.createSequentialGroup()
                        .addGroup(jLayeredPane22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jLayeredPane22Layout.createSequentialGroup()
                                .addGroup(jLayeredPane22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel34, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jLayeredPane22Layout.createSequentialGroup()
                                        .addComponent(jLabel33)
                                        .addGap(99, 99, 99)
                                        .addComponent(jLabel35)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jLayeredPane22Layout.createSequentialGroup()
                                .addGroup(jLayeredPane22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel20)
                                    .addComponent(jLabel27)
                                    .addComponent(lblNome)
                                    .addComponent(jLabel25))
                                .addGap(18, 18, 18)
                                .addGroup(jLayeredPane22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jLayeredPane22Layout.createSequentialGroup()
                                        .addComponent(txtTelefone01, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel21)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtTelefone02, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(135, 135, 135))
                                    .addGroup(jLayeredPane22Layout.createSequentialGroup()
                                        .addComponent(txtNome)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel22)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtCPF, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jLayeredPane22Layout.createSequentialGroup()
                                        .addComponent(txtRua, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel26)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtNumero))
                                    .addGroup(jLayeredPane22Layout.createSequentialGroup()
                                        .addGroup(jLayeredPane22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jLayeredPane22Layout.createSequentialGroup()
                                                .addGap(307, 307, 307)
                                                .addComponent(txtIdCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jLayeredPane22Layout.createSequentialGroup()
                                                .addComponent(txtBalneario, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(78, 78, 78)
                                                .addComponent(jLabel28)
                                                .addGap(18, 18, 18)
                                                .addComponent(txtCidade, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(0, 1, Short.MAX_VALUE)))))
                        .addGap(14, 14, 14))))
        );
        jLayeredPane22Layout.setVerticalGroup(
            jLayeredPane22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane22Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jLayeredPane22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIdCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel35)
                    .addComponent(jLabel33))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel34)
                .addGap(10, 10, 10)
                .addGroup(jLayeredPane22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNome)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22)
                    .addComponent(txtCPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jLayeredPane22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(txtTelefone01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel21)
                    .addComponent(txtTelefone02, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel24)
                .addGroup(jLayeredPane22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jLayeredPane22Layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addGroup(jLayeredPane22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25)
                            .addComponent(txtRua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel26))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jLayeredPane22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel28)
                            .addComponent(txtCidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jLayeredPane22Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(jLayeredPane22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel27)
                            .addComponent(txtBalneario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        btnCadastrar.setBackground(new java.awt.Color(0, 0, 0));
        btnCadastrar.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnCadastrar.setForeground(new java.awt.Color(255, 255, 255));
        btnCadastrar.setText("Cadastrar");
        btnCadastrar.setToolTipText("Cadastrar Cliente");
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });

        btnLimpar.setBackground(new java.awt.Color(0, 0, 0));
        btnLimpar.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnLimpar.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpar.setText("Limpar");
        btnLimpar.setToolTipText("Limpa os Campos Preenchidos");
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        btnPesquisar.setBackground(new java.awt.Color(0, 0, 0));
        btnPesquisar.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnPesquisar.setForeground(new java.awt.Color(255, 255, 255));
        btnPesquisar.setText("Pesquisar");
        btnPesquisar.setToolTipText("Pesquisa um Cliente Pelo Nome");
        btnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarActionPerformed(evt);
            }
        });

        btnVoltar.setBackground(new java.awt.Color(0, 0, 0));
        btnVoltar.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnVoltar.setForeground(new java.awt.Color(255, 255, 255));
        btnVoltar.setText("Voltar");
        btnVoltar.setToolTipText("Retorna ao Menu Principal ");
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        btnExcluir.setBackground(new java.awt.Color(0, 0, 0));
        btnExcluir.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnExcluir.setForeground(new java.awt.Color(255, 255, 255));
        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        tblClientes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        tblClientes.setForeground(new java.awt.Color(0, 0, 0));
        tblClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "IdCliente", "Nome", "Telefone 01", "Telefone02", "CPF", "Rua", "Numero", "Balneario", "Cidade"
            }
        ));
        tblClientes.setToolTipText("Listagem de Clientes");
        jScrollPane1.setViewportView(tblClientes);

        jTabbedPane1.addTab("Clientes", jScrollPane1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPane1)
                    .addComponent(jLayeredPane19, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLayeredPane22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLayeredPane19)
                .addGap(12, 12, 12)
                .addComponent(jLayeredPane22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCadastrar)
                    .addComponent(btnLimpar)
                    .addComponent(btnPesquisar)
                    .addComponent(btnExcluir)
                    .addComponent(btnVoltar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtRuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRuaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRuaActionPerformed

    private void txtTelefone02ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefone02ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefone02ActionPerformed

    private void txtTelefone01ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefone01ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefone01ActionPerformed

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeActionPerformed

    private void btnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarActionPerformed
        String nomeBusca = JOptionPane.showInputDialog(null, "Digite o nome do CLiente que deseja pesquisar: ");
boolean clienteEncontrado = false;

for (Cliente cliente : listaClientes) {
    if (cliente.getNome().equalsIgnoreCase(nomeBusca)) {
        String mensagem = "ID Cliente :" + cliente.getIdCliente() + "\n" +
                          "Telefone 01 :" + cliente.getTelefone01() + "\n" +
                          "Telefone 02 :" + cliente.getTelefone02() + "\n" +
                          "Cpf :" + cliente.getCpf() + "\n" +
                          "Rua :" + cliente.getRua() + "\n"+
                          "Numero :" + cliente.getNumero() + "\n" +
                          "Balneario :" + cliente.getBalneario() + "\n" +
                          "Cidade :" + cliente.getCidade() + "\n";
          
        JOptionPane.showMessageDialog(null, mensagem);
        clienteEncontrado = true;
        
    }
}

if (!clienteEncontrado) {
    JOptionPane.showMessageDialog(null, "Usuário não encontrado.");
}
    }//GEN-LAST:event_btnPesquisarActionPerformed

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        if (!emptyFields()) {
        Cliente cliente = getCliente();
        if (cliente != null) {
            inserirCliente(cliente);
            salvarRegistrosEmArquivo("registros.csv"); // Nome do arquivo onde os registros serão salvos
        }
          txtIdCliente.setText("");
          txtNome.setText("");
          txtTelefone01.setText("");
          txtTelefone02.setText("");
          
          txtCPF.setText("");
          txtRua.setText("");
          txtNumero.setText("");
          txtBalneario.setText("");
          txtCidade.setText("");
          
          
          txtIdCliente.requestFocus();
      }
    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
         
          txtIdCliente.setText("");
          txtNome.setText("");
          txtTelefone01.setText("");
          txtTelefone02.setText("");
          txtCPF.setText("");
          txtRua.setText("");
          txtNumero.setText("");
          txtBalneario.setText("");
          txtCidade.setText("");
          txtIdCliente.requestFocus();
    }//GEN-LAST:event_btnLimparActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        excluirCliente(getPosicaoCliente());
    }//GEN-LAST:event_btnExcluirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CadastroClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CadastroClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CadastroClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CadastroClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroClientes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnPesquisar;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLayeredPane jLayeredPane19;
    private javax.swing.JLayeredPane jLayeredPane22;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lblNome;
    private javax.swing.JTable tblClientes;
    private javax.swing.JTextField txtBalneario;
    private javax.swing.JTextField txtCPF;
    private javax.swing.JTextField txtCidade;
    private javax.swing.JTextField txtIdCliente;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtNumero;
    private javax.swing.JTextField txtRua;
    private javax.swing.JTextField txtTelefone01;
    private javax.swing.JTextField txtTelefone02;
    // End of variables declaration//GEN-END:variables

private boolean emptyFields(){
     /*
      * Variável empty assume “true” por padrão e só vai mudar o seu estado
      * após verificarmos se todos os campos estão preenchidos. É ela que
      * retornamos ao final do método.
     */
     boolean empty = true; 
     
     if(txtNome.getText().trim().isEmpty()){
         
         JOptionPane.showMessageDialog(rootPane, "ATENÇÃO! Nome não pode ser vazio.");
     } else if(txtTelefone01.getText().trim().isEmpty()){
         
          JOptionPane.showMessageDialog(rootPane, "ATENÇÃO! Telefone 01 não pode ser vazio.");
     } else if(txtTelefone02.getText().trim().isEmpty()){
         
          JOptionPane.showMessageDialog(rootPane, "ATENÇÃO! Telefone 02 não pode ser vazio.");
     }   else if(txtCPF.getText().trim().isEmpty()){
        
         JOptionPane.showMessageDialog(rootPane, "ATENÇÃO! CPF não pode ser vazio.");
     } else if(txtRua.getText().trim().isEmpty()){
         
          JOptionPane.showMessageDialog(rootPane, "ATENÇÃO! Rua não pode ser vazio.");
     } else if(txtNumero.getText().trim().isEmpty()){
         
          JOptionPane.showMessageDialog(rootPane, "ATENÇÃO! Numero não pode ser vazio.");
     }   else if(txtBalneario.getText().trim().isEmpty()){
         
         JOptionPane.showMessageDialog(rootPane, "ATENÇÃO! Balneario não pode ser vazio.");
     } else if(txtCidade.getText().trim().isEmpty()){
         
          JOptionPane.showMessageDialog(rootPane, "ATENÇÃO! Cidade não pode ser vazio.");
     }else{
         
         empty = false;
     }
     
     return empty;
  }
 private Cliente getCliente(){
        
     if (!emptyFields() && validarInteiro(Integer.parseInt(txtIdCliente.getText())) 
                && validarTelefone(txtTelefone02.getText())
                && validarTelefone(txtTelefone02.getText())
                && validarCPF(txtCPF.getText())
                )
     {
   
     Cliente cliente = new Cliente(0, "Nome", "Telefone 01", "Telefone 02", "CPF", "Rua", "Numero", "Balneario", "Cidade");
     
     cliente.setIdCliente(Integer.parseInt(txtIdCliente.getText()));
     cliente.setNome(txtNome.getText());
     cliente.setTelefone01(txtTelefone01.getText());
     cliente.setTelefone02(txtTelefone02.getText());
     cliente.setCpf(txtCPF.getText());
     cliente.setRua(txtRua.getText());
     cliente.setNumero(txtNumero.getText());
     cliente.setBalneario(txtBalneario.getText());
     cliente.setCidade(txtCidade.getText());
     
       
       JOptionPane.showMessageDialog(null, "Os seguintes dados foram cadastrados com sucesso: \n"
            + "\nIdCliente: " + txtIdCliente.getText()
            + "\nNome: " + txtNome.getText()
            + "\nTelefone 01: " + txtTelefone01.getText()
            + "\nTelefone 02: " + txtTelefone02.getText()
            + "\nCpf: " + txtCPF.getText()
            + "\nRua: " + txtRua.getText()
            + "\nNumero: " + txtNumero.getText()
            + "\nBalneario: " + txtBalneario.getText()
            + "\nCidade: " + txtCidade.getText()
           );
     
     return cliente;
     
     } else {
    JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos corretamente.");
     }
            return null;
     }
   

   private void inserirCliente(Cliente cliente){
     
     listaClientes.add(cliente);
     
     atualizarTabela();
     
  }
   
   private void atualizarTabela(){
     
     if(!listaClientes.isEmpty()){
         
         Cliente cliente;
         tableModel = new DefaultTableModel(tableColumns, 0);
         for (int i = 0; i < listaClientes.size(); i++) {
             
             cliente = listaClientes.get(i);
             
             String[] rowData = { 
             String.valueOf(cliente.getIdCliente()), 
                 
             cliente.getNome(), cliente.getTelefone01(), 
             cliente.getTelefone02(), 
             cliente.getCpf(), cliente.getRua(),
             cliente.getNumero(), cliente.getBalneario(),
             cliente.getCidade()};
             tableModel.addRow(rowData);
         }
         
         tblClientes.setModel(tableModel);
     }else{
         
         tableModel = new DefaultTableModel(tableColumns, 0);
         tblClientes.setModel(tableModel);
     }     
  }
    private int getPosicaoCliente(){
     
     int posCliente = tblClientes.getSelectedRow();
     if(posCliente == -1){
         JOptionPane.showMessageDialog(rootPane, "Selecione um Registro");
     }
      return posCliente;
  }
       private void excluirCliente(int posCliente){
     
            if(posCliente >= 0){
        
                String[] options = { "Sim", "Não" };
         
         int deletar = JOptionPane.showOptionDialog(
                 rootPane,
                 "Tem certeza que deseja excluir o Registro ?", 
                 "Exclusão  Registro de Funcionario", 
                 JOptionPane.DEFAULT_OPTION, 
                 JOptionPane.QUESTION_MESSAGE, 
                 null, 
                 options, 
                 options[0]
         );
         
         
         if(deletar == 0){
                
                listaClientes.remove(posCliente);

                 
                 atualizarTabela();
         }else{
             /*
             * Limpar a seleção pois o usuário cancelou a exclusão.
             */
            tblClientes.clearSelection();             
         }
     }  
  }
       
       private void salvarRegistrosEmArquivo(String nomeArquivo) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(nomeArquivo))) {
        
        writer.write("idFuncionario, Nome, Telefone 01, Telefone 02, CPF, Rua, Numero, Balneario, Cidade, UsuarioId, cargoId");
        writer.newLine();
         for (Cliente cliente : listaClientes) {
            writer.write(cliente.getIdCliente() 
                    + "," + cliente.getNome() + ","
                    + "," + cliente.getTelefone01() + ","
                    + "," + cliente.getTelefone02() + ","
                    + "," + cliente.getCpf() + ","
                    + "," + cliente.getRua() + ","
                    + "," + cliente.getNumero() + ","
                    + "," + cliente.getBalneario() + ","
                    + "," + cliente.getCidade() + ","
                    
            );
            writer.newLine();
        }
        JOptionPane.showMessageDialog(null, "Registros salvos com sucesso em " + nomeArquivo);
    } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Erro ao salvar registros em arquivo: " + e.getMessage());
    }
} 
   
    // Validação número de telefone
    private boolean validarTelefone(String telefone) {
    if( !telefone.matches("\\(\\d{2}\\)\\d{5}\\-\\d{4}") && !telefone.matches("\\d{11}")){
        JOptionPane.showMessageDialog(null, "Formato de TELEFONE inválido. Use o formato (XX)XXXXX-XXXX.");
        return false;
    }
    return true;
}
    
    //Validar Registro geral
    
    private boolean validarCPF(String Rg) {
    
    if (!Rg.matches("\\d{3}.\\d{3}.\\d{3}-\\d{2}")) {
       
    JOptionPane.showMessageDialog(null, "Formato do Numero do Documento inválido. Use o formato XX.XXX.XXX/X.");
        return false;
    }
    return true;
} 
     //Validar Numeros inteiros
   private boolean validarInteiro(int idCliente) {
    
    if (idCliente < 0 || idCliente > 999) {
        JOptionPane.showMessageDialog(null, "Formato de ID de Funcionário Inválido. Utilize um número entre 0 e 999.");
        return false;
    }
    return true;
}

}
