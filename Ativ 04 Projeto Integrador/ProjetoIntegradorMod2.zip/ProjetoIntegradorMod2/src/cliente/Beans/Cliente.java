package cliente.Beans;

     public class Cliente {
        
        private int idCliente;
        private String nome;
        private String telefone01;
        private String telefone02;
        private String cpf;
        private String rua;
        private String numero;
        private String balneario;
        private String cidade;

    public Cliente(int idCliente, String nome, String telefone01, String telefone02, String cpf, String rua, String numero, String balneario, String cidade) {
        this.idCliente = idCliente;
        this.nome = nome;
        this.telefone01 = telefone01;
        this.telefone02 = telefone02;
        this.cpf = cpf;
        this.rua = rua;
        this.numero = numero;
        this.balneario = balneario;
        this.cidade = cidade;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone01() {
        return telefone01;
    }

    public void setTelefone01(String telefone01) {
        this.telefone01 = telefone01;
    }

    public String getTelefone02() {
        return telefone02;
    }

    public void setTelefone02(String telefone02) {
        this.telefone02 = telefone02;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getBalneario() {
        return balneario;
    }

    public void setBalneario(String balneario) {
        this.balneario = balneario;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

   

   
}
