package financeiro.Bens;

import java.util.ArrayList;
import java.util.List;


    public class ListaVendas {
    
         private static final List<Venda> ListaVendas = new ArrayList<>();
         
         public static List<Venda> Listar() {
        return ListaVendas;
    }

    public static void Adicionar(Venda venda) {
        ListaVendas.add(venda);
    }

    public static void remove(int posVenda) {
        if (posVenda >= 0 && posVenda < ListaVendas.size()) {
            ListaVendas.remove(posVenda);
        } else {
            System.out.println("Índice inválido.");
        
    }
    }
}
