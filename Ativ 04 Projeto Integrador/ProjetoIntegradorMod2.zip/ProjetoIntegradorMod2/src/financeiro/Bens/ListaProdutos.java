package financeiro.Bens;

import java.util.ArrayList;
import java.util.List;


    public class ListaProdutos {
    
         private static final List<Produto> ListaProdutos = new ArrayList<>();

    public static List<Produto> Listar() {
        return ListaProdutos;
    }

    public static void Adicionar(Produto produto) {
        ListaProdutos.add(produto);
    }

    public static void remove(int posProduto) {
        if (posProduto >= 0 && posProduto < ListaProdutos.size()) {
            ListaProdutos.remove(posProduto);
        } else {
            System.out.println("Índice inválido.");
        
    }
    }
}
